<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Enums\ServingSizeEnum;
use App\Models\ServingSize;

class ServingSizeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        foreach (ServingSizeEnum::cases() as $case) {
            ServingSize::create([
                "code" => $case->name,
                "description" => $case->value,
            ]);
        }
    }
}
