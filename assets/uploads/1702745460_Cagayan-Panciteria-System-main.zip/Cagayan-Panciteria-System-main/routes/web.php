<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\TableController;
use App\Http\Controllers\UserProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    event(new App\Events\NotificationEvent(1, "this is just a sample message", "test"));
    if(Auth::check()) {
        return redirect()->route(Auth::user()->is_admin? 'admin.home' : 'client.home');
    }
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Guest Route
Route::group(["prefix" => "guest", "as" => "guest."], function() {
    Route::get("/", [HomeController::class, 'guest'])->name("home");
});


// Client Route
Route::group(["middleware" => ["auth", "client"], "prefix" => "client", "as" => "client."], function() {
    // Home
    Route::get("/", [HomeController::class, 'client'])->name('home');

    // Menu
    Route::get("menu/search/{key?}", [MenuController::class, 'search'])->name('menu.search');
    Route::resource("/menu", MenuController::class);

    // Tables
    Route::get("tables/search/{key?}", [TableController::class, 'search'])->name('tables.search');
    Route::resource("/tables", TableController::class);

    // Order
    Route::get("orders/list", [OrderController::class, 'orders'])->name('orders.list');
    Route::get("orders/search/{key?}", [OrderController::class, 'search'])->name('orders.search');
    Route::delete("orders/destroy-multiple", [OrderController::class, 'destroyMultiple'])->name('orders.destroy-multiple');
    Route::resource("/orders", OrderController::class);

    // Reservation
    Route::resource("/reservations", ReservationController::class);
});

// Admin Route
Route::group(["middleware" =>["auth", "admin"], "prefix" => "admin", "as" => "admin."], function() {
    // Home
    Route::get("/", [HomeController::class, 'admin'])->name('home');

    // Menu
    Route::get("menu/list", [MenuController::class, 'menu'])->name('menu.list');
    Route::get("menu/search/{key?}", [MenuController::class, 'search'])->name('menu.search');
    Route::delete("menu/destroy-multiple", [MenuController::class, 'destroyMultiple'])->name('menu.destroy-multiple');
    Route::resource("menu", MenuController::class);

    // Tables
    Route::get("tables/list", [TableController::class, 'tables'])->name('tables.list');
    Route::get("tables/search/{key?}", [TableController::class, 'search'])->name('tables.search');
    Route::delete("tables/destroy-multiple", [TableController::class, 'destroyMultiple'])->name('tables.destroy-multiple');
    Route::resource("tables", TableController::class);

    // Order
    Route::get("orders/list", [OrderController::class, 'orders'])->name('orders.list');
    Route::get("orders/search/{key?}", [OrderController::class, 'search'])->name('orders.search');
    Route::delete("orders/destroy-multiple", [OrderController::class, 'destroyMultiple'])->name('orders.destroy-multiple');
    Route::resource("orders", OrderController::class);

    // Reservation
    Route::resource("reservations", ReservationController::class);

    // Inventory
    Route::get("inventory/list", [InventoryController::class, 'inventory'])->name('inventory.list');
    Route::get("inventory/search/{key?}", [InventoryController::class, 'search'])->name('inventory.search');
    Route::delete("inventory/destroy-multiple", [InventoryController::class, 'destroyMultiple'])->name('inventory.destroy-multiple');
    Route::resource("inventory", InventoryController::class);

    // User
    Route::get("users/list", [UserProfileController::class, 'users'])->name('users.list');
    Route::get("users/search/{key?}", [UserProfileController::class, 'search'])->name('users.search');
    Route::delete("users/destroy-multiple", [UserProfileController::class, 'destroyMultiple'])->name('users.destroy-multiple');
    Route::resource("users", UserProfileController::class);
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
