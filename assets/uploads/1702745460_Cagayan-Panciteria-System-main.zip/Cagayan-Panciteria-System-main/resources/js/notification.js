import Push from "push.js";
window.Push = Push;

var push = (({title: title, message: message, icon: icon}) => {
    if(typeof(icon) === "undefined") {
        icon  = './images/logo.jpg';
    }
    return Push.create(title, {
        body: message,
        icon: icon,
        onClick: function () {
            window.focus();
            this.close();
        },
        onClose: function () {
            this.clear();
        }
    });
});

export default {push: push};