import Swal from 'sweetalert2';

let alert = Swal.mixin({
        showCancelButton: true,
        cancelButtonColor: "#1f2937",
        confirmButtonColor: "#339476",
        customClass: {
            actions: 'custom-action',
            cancelButton: 'order-1',
            confirmButton: 'order-2',
        }
    });

let dialog = Swal.mixin({
    confirmButtonColor: "#1f2937",
    confirmButtonText: "Close",
    
    customClass: {
        actions: 'custom-action',
        confirmButton: 'order-1',
    }
});

export default { alert: alert, dialog: dialog };