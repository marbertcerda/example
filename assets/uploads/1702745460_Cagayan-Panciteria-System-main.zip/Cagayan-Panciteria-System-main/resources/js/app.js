import './bootstrap';

// third-party modules
import Alpine from 'alpinejs';
import jquery from 'jquery';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

// custom modules
import Notify from './notification';
import Calendar from './calendar';
import 'jquery-mask-plugin';
import method from './methods';
import toast from './toast';
import dialog from './dialog';

window.Alpine = Alpine;
window.$ = jquery;
window.CkEditor = ClassicEditor;

window.Calendar = Calendar;
window.Notify = Notify;
window.method = method;
window.Toast = toast.toast;
window.Alert = dialog.alert;
window.Dialog = dialog.dialog;

Alpine.start();
