import { Calendar } from '@fullcalendar/core';
import interaction from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';

let calendar = function(container) {
    var cal = new Calendar(container[0], {
        nowIndicator: true,
        editable: false,
        selectable: true,
        handleWindowResize: true,
        allDaySlot: false,
        eventOverlap: false,
        slotDuration: "01:00:00",
        eventColor: "#339476",
        aspectRatio: window.innerWidth >= 768 ? 1.75 : 0.75,
        plugins: [ dayGridPlugin, timeGridPlugin, listPlugin, interaction ],
        initialView: window.innerWidth >= 768 ?  'dayGridMonth' : 'listWeek',
        headerToolbar: {
            left: 'title',
            center: '',
            right: 'today dayGridMonth,timeGridWeek,listWeek prev,next'
        },
        windowResize: function(view) {
            if (window.innerWidth >= 768 ) {
                cal.setOption('aspectRatio', 1.75);
            } else {
                cal.setOption('aspectRatio', 0.75);
            }
        },
        eventClick: function(info) {
            alert(`${info.event.title} \n ${info.event.start} - ${info.event.end}`);
        },
    });
    return cal;
}
export default {calendar: calendar};