// Toggle Button
const toggleButton = (({
    selected: selected, 
    button: button, 
    isEnabled: isEnabled, 
    text: text 
}) => {
    let btn;
    if(isEnabled) {
        $.each(button, function() {
            btn = $(this);
            if(typeof(selected !== "undefined") && selected.attr("id") === btn.attr("id")) {
                btn.children().first().show('fast', 'linear');
                btn.children().last().html(text);
            }
            btn.prop('disabled', isEnabled);
        });
        return false;
    }

    $.each(button, function()  {
        btn = $(this);
        if(typeof(selected !== "undefined") && selected.attr("id") === btn.attr("id")) {
            btn.children().first().hide('fast', 'linear');
            btn.children().last().html(text);
        }
        btn.prop('disabled', isEnabled);
    });
});

// Load Data by Form Request
const load = (({
    link: link,
    container: container,
    loader: loader,
}) => {
    container.empty();
    loader.show("fast", "linear");

    container.load(link, function(data, status) {
        loader.hide("fast", "linear");
    });
});

// Submit Form Request
const submit = (({
    form: form,
    edit: edit,
    editor: editor,
    indicator: indicator,
    preview: preview,
    container: container,
    selected: selected,
    button: button,
    text: text,
}) => {
    let errField = $(".error");
    let data = new FormData(form.get(0));
    let link = form.attr('action');

    if(edit) {
        data.append("_method","put");
    }

    // Toggle Button
    toggleButton({
        selected: selected,
        button: button,
        isEnabled: true,
        text: text[0],
    });

    // Submit Form
    $.ajax({
        type: "POST",
        url: link,
        dataType: 'JSON',
        data: data,
        contentType: false,
        processData: false,
        cache: false,
        success: function(data, status) {
            errField.html("");
            errField.hide("fast", "linear");

            if(!data.success) {
                Toast.fire({icon: 'warning', text: data.message});
            }

            // default fallback for sucessful request
            else {
                Toast.fire({icon: 'success', text: data.message});

                if(!edit) {
                    form.get(0).reset();
                }
                
                if(typeof(container) !== "undefined") {
                    container.load(data.link, function(){});
                }

                if(typeof(preview) !== "undefined" && !edit) {
                    $.each(preview, function() {
                        $(this).attr("src", "");
                        $(this).hide("fast", "linear");
                    });
                }
                
                if(typeof(editor) !== "undefined" && !edit) {
                    editor.setData("");
                }

                if(typeof(indicator) !== "undefined" && !edit) {
                    $.each(indicator, function() {
                        if($(this).is(":hidden")) {
                            $(this).show("fast", "linear");
                        }
                    });
                }
            }
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: false,
                text: text[1],
            });
        }, 
        error: function(error, status, thrown) {
            errField.html("");
            errField.hide("fast", "linear");

            if(typeof(error.responseJSON) !== "undefined") {
                let errors = error.responseJSON.errors
                for(let key in errors) {
                    let errorDiv = form.find(`.error[data-error="${key}"]`);
                    if(errorDiv.length ) {
                        errorDiv.text(errors[key][0]);
                        errorDiv.show("fast", "linear");
                    }
                }
            }
            Toast.fire({icon: 'error', text: `Error excuting request. Reason:  ${thrown}. Please try again.`});
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: false,
                text: text[1],
            });
        }
    });
});

// Submit Delete Request
const destroy = (({
    modalHeader: modalHeader,
    modalText: modalText,
    form: form,
    container: container,
    button: button,
    selected: selected,
    text: text,
}) => {
    let data = form.serializeArray();
    let link = form.attr("action");

    // check if no _method exists in the data
    if(!data.find(e => e.name === '_method')) {
        data.push({name: "_method", value: "delete"});
    }

    Alert.fire({
        icon: "warning",
        title: modalHeader,
        text: modalText,
    }).then(function(result) {
        if(result.isConfirmed) {
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: true,
                text: text[0],
            });
            execute();
        }
        else {
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: false,
                text: text[1],
            });
        }
    });

    function execute() {
        $.post(link, data, function(data, status) {
            if(data.success) {
                Toast.fire({icon: 'success', text: data.message});
                container.load(data.link, function(){});
                toggleButton({
                    selected: selected,
                    button: button,
                    isEnabled: false,
                    text: text[1],
                });
                return true;
            }
            Toast.fire({icon: 'warning', text: data.message});
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: false,
                text: text[1],
            });
        }).fail(function(error, status, thrown) {
            Toast.fire({icon: 'error', text: `Error deleting selected records. Reason: ${thrown}`});
            toggleButton({
                selected: selected,
                button: button,
                isEnabled: false,
                text: text[1],   
            });
        });
    }
});

// Authenticate by User's Request
const authenticate = (({
    form: form,
    redirect: redirect,
    button: button,
    selected: selected,
    text: text,
}) => {
    let data = form.serializeArray();
    let link = form.attr("action");
    let errField = form.find(".error");

    // Toggle Button
    toggleButton({
        selected: selected,
        button: button,
        isEnabled: true,
        text: text[0],
    });

    $.post(link, data, function(data, status) {
        errField.html("");
        errField.hide("fast", "linear");
        
        if(data.success) {
            Toast.fire({icon: 'success', text: data.message});
            if(redirect) {
                window.location.href = data.link;
            }
        }
        else {
            Toast.fire({icon: 'warning', text: data.message});
        }
        // Toggle Button
        toggleButton({
            selected: selected,
            button: button,
            isEnabled: false,
            text: text[1],
        });
    }).fail(function(error, status, thrown) {
        errField.html("");

        if(typeof(error.responseJSON) !== "undefined") {
            let errors = error.responseJSON.errors
            for(let key in errors) {
                let errorDiv = form.find(`.error[data-error="${key}"]`);
                if(errorDiv.length ) {
                    errorDiv.text(errors[key][0]);
                    errorDiv.show("fast", "linear");
                }
            }
        }
        Toast.fire({icon: 'error', text: `Authentication error. Reason:  ${thrown}. Please try again.`});
        toggleButton({
            selected: selected,
            button: button,
            isEnabled: false,
            text: text[1],
        });
    });

});

export default {
    toggleButton: toggleButton,
    load: load,
    submit: submit,
    destroy: destroy,
    authenticate: authenticate,
};