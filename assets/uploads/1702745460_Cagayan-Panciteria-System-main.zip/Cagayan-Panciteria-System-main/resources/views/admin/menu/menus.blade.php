<form id="delete-menu-form" action="{{set_route('menu.destroy-multiple')}}" method="post">
    @method('delete')
    @csrf

    <x-table>
        <x-slot name="thead">
            <x-cell type="th">
                <x-checkbox id="select-all" />
            </x-cell>
            <x-cell type="th">Image</x-cell>
            <x-cell type="th" class="whitespace-nowrap">Name</x-cell>
            <x-cell type="th" class="w-1/2">Description</x-cell>
            <x-cell type="th" class="whitespace-nowrap">Sizes</x-cell>
            <x-cell type="th" class="whitespace-nowrap">Price</x-cell>
            <x-cell type="th">Available</x-cell>
            <x-cell type="th" class="whitespace-nowrap">Date Added</x-cell>
            <x-cell type="th" class="whitespace-nowrap">Last Modified</x-cell>
        </x-slot>
        <x-slot name="tbody">
            @forelse($menus as $menu)
            <tr>
                <x-cell type="td">
                    <x-checkbox name="menu[]" :value="$menu->id" />
                </x-cell>
                <x-cell type="td" class="w-12 h-12">
                    <img src="{{ asset('storage/menus/'.$menu->photo) }}" alt="" class="w-full aspect-square rounded-full object-cover object-center">
                </x-cell>
                <x-cell type="td"><x-link href="{{set_route('menu.edit', $menu)}}" x-data='' x-on:click.prevent="$dispatch('open-modal', 'show-edit-menu-form')" class="edit-link">{{$menu->name}}</x-link></x-cell>
                <x-cell type="td">{!! Illuminate\Support\Str::limit(strip_tags($menu->description), 50, '...') !!}</x-cell>
                <x-cell type="td" class="prose whitespace-nowrap">
                    <ul>
                    @foreach($menu->size as $serving)
                        <li>{{ucwords($serving->description)}}</li>
                    @endforeach
                    </ul>
                </x-cell>
                <x-cell type="td" class="prose whitespace-nowrap">
                    <ul>
                    @foreach($menu->size as $serving)
                        <li>@money($serving->pivot->price2)</li>
                    @endforeach
                    </ul>
                </x-cell>
                <x-cell type="td">{{$menu->is_available? "Yes" : "No"}}</x-cell>
                <x-cell type="td" class="whitespace-nowrap">{{Carbon\Carbon::parse($menu->created_at)->format('M d, Y \a\\t h:i A')}}</x-cell>
                <x-cell type="td" class="whitespace-nowrap">{{Carbon\Carbon::parse($menu->updated_at)->diffForHumans()}}</x-cell>
            </tr>
            @empty
            <tr>
                <x-cell type="td" colspan="9" align="center"> No Menu found. Added Menu/s will be shown here.  </x-cell>
            </tr>
            @endforelse
        </x-slot>
    </x-table>
</form>

<script type="module">
    // Enable delete button if a checkbox is clicked
    $("#delete-menu-form").change(function() {
        let button = $("#delete-menu-button");
        let checkboxes = $(this).find("tbody input[type=checkbox]");
        let selectAll = $(this).find("#select-all");
        
        button.prop("disabled", checkboxes.filter(":checked").length === 0);
        if(checkboxes.length > 0) {
            selectAll.prop("checked", checkboxes.filter(":checked").length === checkboxes.length);
        }
    });

    $("#select-all").change(function() {
        let checkboxes = $("#delete-menu-form").find("tbody input[type=checkbox]");
        checkboxes.prop('checked', $(this).is(":checked"));
    });

    // Edit Menu
    $("a.edit-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr("href"), 
            container: $("#edit-menu-container"), 
            loader: $("#edit-menu-loader")
        });
    });

    // Delete Menu/s
    $("#delete-menu-form").submit(function(e) {
        e.preventDefault();
        console.log($(this).serializeArray());
        method.destroy({
            modalHeader: "Delete Menu Confirmation",
            modalText: "Once done, this action is irreversible. Are you sure you want to delete the selected menus?",
            form: $(this),
            container: $("#menu-container"),
            button: [$("#delete-menu-button"), $("#add-menu-button")],
            selected: $("#delete-menu-button"),
            text: ["Deleting Menu/s...", "Delete Menu/s"],
        });
    });
</script>