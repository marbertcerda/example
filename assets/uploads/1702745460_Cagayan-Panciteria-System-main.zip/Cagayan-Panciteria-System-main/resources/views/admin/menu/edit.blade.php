<form id="update-menu-form" action="{{ set_route('menu.update', $menu) }}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @method('put')
    @csrf
    
    <div>
        <x-input-label for="name-field" value="Name: " />
        <x-text-input type="text" id="name-field" name="name" :value="old('name', $menu->name)" placeholder="Enter menu name" class="w-full" autofill autocomplete="name" />
        <x-input-error :messages="$errors->get('name')" data-error="name" />
    </div>

    <div class="space-y-2">
        <x-input-label for="menu-sizes" value="Available Sizes:" />
        @foreach(App\Enums\ServingSizeEnum::cases() as $case)
        <div>
            <div class="flex flex-col sm:flex-row sm:items-center gap-x-2">
                <div class="w-full sm:w-2/5">
                    <label for="new-size-{{$case->name}}" class="flex items-center gap-2 w-full">
                        <x-checkbox id="new-size-{{$case->name}}" name="size[{{$case->name}}]" :value="$case->value" class="new-size-item" :checked="isset($servings[$case->name])" />
                        <span>{{ucwords($case->value)}}</span>
                    </label>
                    <x-input-error :messages="$errors->get('size[$case->name]')" data-error="size.{{$case->name}}" />
                </div>
                <div class="w-full sm:w-3/5">
                    <x-text-input type="number" id="new-price-{{$case->name}}" name="price[{{$case->name}}]" :value="old('price[$case->name]', (isset($servings[$case->name])? $servings[$case->name]->pivot->price : ''))" step=".01" placeholder="Enter price" class="w-full" autofill :disabled="!isset($servings[$case->name])" />
                    <input type="hidden" name="old-price-{{$case->name}}" value="{{isset($servings[$case->name])? $servings[$case->name]->pivot->price : ''}}">
                    <x-input-error :messages="$errors->get('price[$case->name]')" data-error="price.{{$case->name}}" />
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div class="prose">
        <x-input-label for="new-description-field" value="Description: " />
        <x-textarea id="new-description-field" name="description" class="w-full" placeholder="Enter menu description" autofill autocomplete="description">{!! old('description', $menu->description) !!}</x-textarea>
        <x-input-error :messages="$errors->get('description')" data-error="description" />
    </div>

    <div>
        <x-input-label for="new-photo-field" value="Photo: " />
        <div id="new-photo-container" class="flex justify-center items-center h-56 w-full border-2 border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="new-upload-label" class="hidden first-letter:label text-xs"> Tap Here to Upload Photo </div>
            <img id="new-photo-preview" src="{{asset('storage/menus/'.$menu->photo)}}" alt="..." class="object-cover object-center">
        </div>
        <input type="file" name="photo" id="new-photo-field" accept="image/*" class="absolute opacity-0 pointer-events-none">
        <input type="hidden" id="old-photo-field" name="old_photo" value="{{asset('storage/menus/'.$menu->photo)}}">
        <x-input-error :messages="$errors->get('photo')" data-error="photo" />
    </div>
</form>
<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="update-menu-form" id="update-menu-button"  class="form-button"> Update Menu </x-primary-button>
</div>

<script type="module">
    // preload CKEditor
    let editor;
    $(document).ready(function() {
        let textField = $("#new-description-field").get(0);
        CkEditor.create(textField, {
            toolbar: [ "undo", "redo", "selectAll", "|", "heading", "|", "bold", "italic", "|", "link", "blockQuote", "|", "indent", "outdent", "bulletedList", "numberedList"]
        }).then(function(editField) {
            editor = editField;
        }).catch(function(error) {
            console.log(error);
        });
    });

    // toggle price field if checkbox is checked
    $(".new-size-item").change(function() {
        let field = $(this).parent().parent().next().find("input[type=number]");
        let isChecked = $(this).is(":checked");
        
        $(field).prop("disabled", !isChecked);

        if(isChecked) {
            field.val(field.next().val())
            field.focus();
        }  
        else {
            field.val("");
        }
    });

    // photo preview
    $("#new-photo-container").click(function() {
        let fileInput = $("#new-photo-field");
        fileInput.click();
    });

    $("#new-photo-field").change(function(e) {
        let container = $("#new-photo-container");
        let preview = $("#new-photo-preview");
        let old = $("#old-photo-field").val();
        let reader = new FileReader();


        if(this.files.length != 0) {
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
        }

        else {
            preview.attr('src', old);
        }
    });

    $("#update-menu-form").submit(function(e) {
        e.preventDefault();
        editor.updateSourceElement();

        method.submit({
            form: $(this),
            edit: true,
            editor: editor,
            indicator: $("#new-upload-label"),
            preview: $("#new-photo-preview"),
            container: $("#menu-container"),
            selected: $("#update-menu-button"),
            button: $(".form-button"),
            text: ["Updating Menu...", "Update Menu"],
        });
    });
</script>