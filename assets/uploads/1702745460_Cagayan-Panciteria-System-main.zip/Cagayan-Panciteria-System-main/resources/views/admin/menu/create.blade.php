<form id="add-to-menu-form" action="{{ set_route('menu.store') }}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @csrf
    
    <div>
        <x-input-label for="name-field" value="Name: " />
        <x-text-input type="text" id="name-field" name="name" :value="old('name')" placeholder="Enter menu name" class="w-full" autofill />
        <x-input-error :messages="$errors->get('name')" data-error="name" />
    </div>

    <div class="space-y-2">
        <x-input-label for="menu-sizes" value="Available Sizes:" />
        @foreach(App\Enums\ServingSizeEnum::cases() as $case)
        <div>
            <div class="flex flex-col sm:flex-row sm:items-center gap-x-2">
                <div class="w-full sm:w-2/5">
                    <label for="size-{{$case->name}}" class="flex items-center gap-2">
                        <x-checkbox id="size-{{$case->name}}" name="size[{{$case->name}}]" :value="$case->value" class="size-item" />
                        <span>{{ucwords($case->value)}}</span>
                    </label>
                    <x-input-error :messages="$errors->get('size[$case->name]')" data-error="size.{{$case->name}}" />
                </div>
                <div class="w-full sm:w-3/5">
                    <x-text-input type="number" id="price-{{$case->name}}" name="price[{{$case->name}}]" step=".01" placeholder="Enter price" class="w-full" autofill :disabled="true" />
                    <x-input-error :messages="$errors->get('price[$case->name]')" data-error="price.{{$case->name}}" />
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div id="new-field-container"></div>

    <div class="prose">
        <x-input-label for="description-field" value="Description: " />
        <x-textarea id="description-field" name="description" class="w-full" placeholder="Enter menu description" autofill>{!! old('description') !!}</x-textarea>
        <x-input-error :messages="$errors->get('description')" data-error="description" />
    </div>

    <div>
        <x-input-label for="photo-field" value="Photo: " />
        <div id="photo-container" class="flex justify-center items-center h-56 w-full border-2 border-dashed hover:border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="upload-label" class="label text-xs"> Tap Here to Upload Photo </div>
            <img id="photo-preview" src="" alt="..." class="hidden object-cover object-center">
        </div>
        <input type="file" name="photo" id="photo-field" accept="image/*" class="absolute opacity-0 pointer-events-none" required>
        <x-input-error :messages="$errors->get('photo')" data-error="photo" />
    </div>
</form>
<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="add-to-menu-form" id="add-to-menu-button"  class="form-button"> Add to Menu </x-primary-button>
</div>

<script type="module">
    // preload CKEditor
    let editor;
    $(document).ready(function() {
        let textField = $("#description-field").get(0);
        CkEditor.create(textField, {
            toolbar: [ "undo", "redo", "selectAll", "|", "heading", "|", "bold", "italic", "|", "link", "blockQuote", "|", "indent", "outdent", "bulletedList", "numberedList"]
        }).then(function(editField) {
            editor = editField;
        }).catch(function(error) {
            console.log(error);
        });
    });

    // toggle price field if checkbox is checked
    $(".size-item").change(function() {
        let field = $(this).parent().parent().next().find("input[type=number]");
        let isChecked = $(this).is(":checked");
        
        $(field).prop("disabled", !isChecked);

        isChecked? field.focus() : field.val("");       
    });

    // photo preview
    $("#photo-container").click(function() {
        let fileInput = $("#photo-field");
        fileInput.click();
    });

    $("#photo-field").change(function(e) {
        let container = $("#photo-container");
        let preview = $("#photo-preview");
        let label = $("#upload-label");
        let reader = new FileReader();


        if(this.files.length != 0) {
            label.hide('fast', 'linear');
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
                preview.show('fast', 'linear');
            }
            reader.readAsDataURL(this.files[0]);
            container.removeClass("border-dashed");
        }

        else {
            preview.attr('src', '');
            preview.hide('fast', 'linear', function() {
                label.show('fast', 'linear');
                container.addClass("border-dashed");
            });
        }
    });

    $("#add-to-menu-form").submit(function(e) {
        e.preventDefault();
        editor.updateSourceElement();

        method.submit({
            form: $(this),
            edit: false,
            editor: editor,
            indicator: $("#upload-label"),
            preview: $("#photo-preview"),
            container: $("#menu-container"),
            selected: $("#add-to-menu-button"),
            button: $(".form-button"),
            text: ["Adding to Menu...", "Add to Menu"],
        });
    });
</script>