<x-app-layout>
    <x-slot name="header">
        <x-header>{{ __('Admin Orders Screen') }}</x-header>
    </x-slot>

    <x-section>
        <x-container>
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('orders.search')}}" method="get" class="w-full sm:w-1/2 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <!-- <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="delete-order-button" form="delete-order-form" :disabled="true">Delete Menu/s</x-danger-button>
                        <x-primary-button id="add-order-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-add-order-form')">Add Menu</x-primary-button>
                    </div> -->
                </div>
            </x-slot>
            <x-loader id="order-loader" />
            <div id="order-container" class="overflow-x-auto no-scrollbar">
                @include('admin.orders.orders')
            </div>
        </x-container>
    </x-section>

    <!-- Add Menu Form -->
    <!-- <x-modal name="show-add-order-form" title="Add New Menu">
        
    </x-modal> -->

    <!-- Edit Menu Form -->
    <!-- <x-modal name="show-edit-order-form" title="Edit Menu" containerId="edit-order-container">
        <x-slot name="loader">
            <x-loader id="edit-order-loader" />
        </x-slot>
    </x-modal> -->

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#order-loader"),
                container: $("#order-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>