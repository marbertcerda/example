<form id="edit-inventory-form" action="{{ set_route('inventory.update', $inventory) }}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @method('put')
    @csrf
    
    <div>
        <x-input-label for="new-name-field" value="Name: " />
        <x-text-input type="text" id="new-name-field" name="name" :value="old('name', $inventory->name)" placeholder="Enter inventory name" class="w-full" autofill />
        <x-input-error :messages="$errors->get('name')" data-error="name" />
    </div>

    <div class="flex flex-col sm:flex-row gap-2">
        <div class="w-full sm:w-1/2">
            <x-input-label for="new-stock-field" value="Stock: " />
            <x-text-input type="number" id="new-stock-field" name="stock" :value="old('stock', $inventory->stock)" step=".01" placeholder="Enter inventory stock" class="w-full" autofill />
            <x-input-error :messages="$errors->get('stock')" data-error="stock" />
        </div>
        
        <div class="w-full sm:w-1/2">
            <x-input-label for="new-unit-field" value="Unit of Measurement: " />
            <x-select name="unit" id="new-unit-field" class="w-full" autofill>
                <option value="" selected disabled>- Select One -</option>
                @foreach(App\Enums\InventoryUnitEnum::cases() as $case)
                <option value="{{$case}}"@if($case === $inventory->unit) {{'selected'}} @endif>{{ucfirst($case->value).' ('.$case->name.')'}}</option>
                @endforeach
            </x-select>
            <x-input-error :messages="$errors->get('unit')" data-error="unit" />
        </div>
    </div>

    <div class="prose">
        <x-input-label for="new-description-field" value="Description: " />
        <x-textarea id="new-description-field" name="description" class="w-full" placeholder="Enter inventory description" autofill>{!! old('description', $inventory->description) !!}</x-textarea>
        <x-input-error :messages="$errors->get('description')" data-error="description" />
    </div>

    <div>
        <x-input-label for="new-photo-field" value="Photo: " />
        <div id="new-photo-container" class="flex justify-center items-center h-56 w-full border-2 border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="new-upload-label" class="hidden first-letter:label text-xs"> Tap Here to Upload Photo </div>
            <img id="new-photo-preview" src="{{asset('storage/inventories/'.$inventory->photo)}}" alt="..." class="object-cover object-center">
        </div>
        <input type="file" name="photo" id="new-photo-field" accept="image/*" class="absolute opacity-0 pointer-events-none">
        <input type="hidden" id="old-photo-field" name="old_photo" value="{{asset('storage/inventories/'.$inventory->photo)}}">
        <x-input-error :messages="$errors->get('photo')" data-error="photo" />
    </div>
</form>
<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="edit-inventory-form" id="edit-inventory-button"  class="form-button"> Update Inventory </x-primary-button>
</div>

<script type="module">
    // preload CKEditor
    let editor;
    $(document).ready(function() {
        let textField = $("#new-description-field").get(0);
        CkEditor.create(textField, {
            toolbar: [ "undo", "redo", "selectAll", "|", "heading", "|", "bold", "italic", "|", "link", "blockQuote", "|", "indent", "outdent", "bulletedList", "numberedList"]
        }).then(function(editField) {
            editor = editField;
        }).catch(function(error) {
            console.log(error);
        });
    });

    // photo preview
    $("#new-photo-container").click(function() {
        let fileInput = $("#new-photo-field");
        fileInput.click();
    });

    $("#new-photo-field").change(function(e) {
        let container = $("#new-photo-container");
        let preview = $("#new-photo-preview");
        let old = $("#old-photo-field").val();
        let reader = new FileReader();


        if(this.files.length != 0) {
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
                preview.show('fast', 'linear');
            }
            reader.readAsDataURL(this.files[0]);
        }

        else {
            preview.attr('src', old);
        }
    });

    $("#edit-inventory-form").submit(function(e) {
        e.preventDefault();
        editor.updateSourceElement();

        method.submit({
            form: $(this),
            edit: true,
            editor: editor,
            indicator: $("#new-upload-label"),
            preview: $("#new-photo-preview"),
            container: $("#inventory-container"),
            selected: $("#edit-inventory-button"),
            button: $(".form-button"),
            text: ["Updating Inventory...", "Update Inventory"],
        });
    });
</script>