<x-app-layout>
    <x-slot name="header">
        <x-header>{{ __('Admin Inventory Screen') }}</x-header>
    </x-slot>

    <x-section>
        <x-container>
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('inventory.search')}}" method="get" class="w-full sm:w-1/3 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="delete-inventory-button" form="delete-inventory-form" :disabled="true">Delete Inventory/ies</x-danger-button>
                        <x-primary-button id="add-inventory-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-add-inventory-form')">Add Inventory</x-primary-button>
                    </div>
                </div>
            </x-slot>
            <x-loader id="inventory-loader" />
            <div id="inventory-container" class="overflow-x-auto no-scrollbar">
                @include('admin.inventory.inventory')
            </div>
        </x-container>
    </x-section>

    <!-- Add Inventory Form -->
    <x-modal name="show-add-inventory-form" title="Add New Inventory">
        @include('admin.inventory.create')
    </x-modal>

    <!-- Edit Inventory Form -->
    <x-modal name="show-edit-inventory-form" title="Edit Inventory" containerId="edit-inventory-container">
        <x-slot name="loader">
            <x-loader id="edit-inventory-loader" />
        </x-slot>
    </x-modal>

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#inventory-loader"),
                container: $("#inventory-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>