<form id="add-to-inventory-form" action="{{ set_route('inventory.store') }}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @csrf
    
    <div>
        <x-input-label for="name-field" value="Name: " />
        <x-text-input type="text" id="name-field" name="name" :value="old('name')" placeholder="Enter inventory name" class="w-full" autofill />
        <x-input-error :messages="$errors->get('name')" data-error="name" />
    </div>

    <div class="flex flex-col sm:flex-row gap-2">
        <div class="w-full sm:w-1/2">
            <x-input-label for="stock-field" value="Stock: " />
            <x-text-input type="number" id="stock-field" name="stock" :value="old('stock')" step=".01" placeholder="Enter inventory stock" class="w-full" autofill />
            <x-input-error :messages="$errors->get('stock')" data-error="stock" />
        </div>
        
        <div class="w-full sm:w-1/2">
            <x-input-label for="unit-field" value="Unit of Measurement: " />
            <x-select name="unit" id="unit-field" class="w-full" autofill>
                <option value="" selected disabled>- Select One -</option>
                @foreach(App\Enums\InventoryUnitEnum::cases() as $case)
                <option value="{{$case}}">{{ucfirst($case->value).' ('.$case->name.')'}}</option>
                @endforeach
            </x-select>
            <x-input-error :messages="$errors->get('unit')" data-error="unit" />
        </div>
    </div>

    <div class="prose">
        <x-input-label for="description-field" value="Description: " />
        <x-textarea id="description-field" name="description" class="w-full" placeholder="Enter inventory description" autofill>{!! old('description') !!}</x-textarea>
        <x-input-error :messages="$errors->get('description')" data-error="description" />
    </div>

    <div>
        <x-input-label for="photo-field" value="Photo: " />
        <div id="photo-container" class="flex justify-center items-center h-56 w-full border-2 border-dashed hover:border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="upload-label" class="label text-xs"> Tap Here to Upload Photo </div>
            <img id="photo-preview" src="" alt="..." class="hidden object-cover object-center">
        </div>
        <input type="file" name="photo" id="photo-field" accept="image/*" class="absolute opacity-0 pointer-events-none" required>
        <x-input-error :messages="$errors->get('photo')" data-error="photo" />
    </div>
</form>
<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="add-to-inventory-form" id="add-to-inventory-button"  class="form-button"> Add to Inventory </x-primary-button>
</div>

<script type="module">
    // preload CKEditor
    let editor;
    $(document).ready(function() {
        let textField = $("#description-field").get(0);
        CkEditor.create(textField, {
            toolbar: [ "undo", "redo", "selectAll", "|", "heading", "|", "bold", "italic", "|", "link", "blockQuote", "|", "indent", "outdent", "bulletedList", "numberedList"]
        }).then(function(editField) {
            editor = editField;
        }).catch(function(error) {
            console.log(error);
        });
    });

    // photo preview
    $("#photo-container").click(function() {
        let fileInput = $("#photo-field");
        fileInput.click();
    });

    $("#photo-field").change(function(e) {
        let container = $("#photo-container");
        let preview = $("#photo-preview");
        let label = $("#upload-label");
        let reader = new FileReader();


        if(this.files.length != 0) {
            label.hide('fast', 'linear');
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
                preview.show('fast', 'linear');
            }
            reader.readAsDataURL(this.files[0]);
            container.removeClass("border-dashed");
        }

        else {
            preview.attr('src', '');
            preview.hide('fast', 'linear', function() {
                label.show('fast', 'linear');
                container.addClass("border-dashed");
            });
        }
    });

    $("#add-to-inventory-form").submit(function(e) {
        e.preventDefault();
        editor.updateSourceElement();

        method.submit({
            form: $(this),
            edit: false,
            editor: editor,
            indicator: $("#upload-label"),
            preview: $("#photo-preview"),
            container: $("#inventory-container"),
            selected: $("#add-to-inventory-button"),
            button: $(".form-button"),
            text: ["Adding to Inventory...", "Add to Inventory"],
        });
    });
</script>