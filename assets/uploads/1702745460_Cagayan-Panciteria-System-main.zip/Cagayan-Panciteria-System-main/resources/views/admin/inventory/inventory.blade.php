<form id="delete-inventory-form" action="{{set_route('inventory.destroy-multiple')}}" method="post">
    @method('delete')
    @csrf

    <x-table>
        <x-slot name="thead">
            <x-cell type="th">
                <x-checkbox id="select-all" />
            </x-cell>
            <x-cell type="th"></x-cell>
            <x-cell type="th">Name</x-cell>
            <x-cell type="th">Description</x-cell>
            <x-cell type="th">Stocks</x-cell>
            <x-cell type="th">Unit</x-cell>
            <x-cell type="th">Date Added</x-cell>
            <x-cell type="th">Last Modified</x-cell>
        </x-slot>
        <x-slot name="tbody">
            @forelse($inventories as $inventory)
            <tr>
                <x-cell type="td" align="center">
                    <x-checkbox name="inventory[]" :value="$inventory->id" />
                </x-cell>
                <x-cell type="td" class="w-12 h-12">
                    <img src="{{ asset('storage/inventories/'.$inventory->photo) }}" alt="" class="w-full aspect-square rounded-full object-cover object-center">
                </x-cell>
                <x-cell type="td"><x-link href="{{set_route('inventory.edit', $inventory)}}" x-data='' x-on:click.prevent="$dispatch('open-modal', 'show-edit-inventory-form')" class="edit-link">{{$inventory->name}}</x-link></x-cell>
                <x-cell type="td">{!! Illuminate\Support\Str::limit(strip_tags($inventory->description), 100, '...') !!}</x-cell>
                <x-cell type="td">{{$inventory->stock}}</x-cell>
                <x-cell type="td">{{$inventory->unit}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($inventory->created_at)->format('M d, Y \a\\t h:i A')}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($inventory->updated_at)->diffForHumans()}}</x-cell>
            </tr>
            @empty
            <tr>
                <x-cell colspan="8" align="center"> No Inventories found. Added Inventory/iess will be shown here.  </x-cell>
            </tr>
            @endforelse
        </x-slot name="tbody">
    </x-table>
</form>

<script type="module">
    // Enable delete button if a checkbox is clicked
    $("#delete-inventory-form").change(function() {
        let button = $("#delete-inventory-button");
        let checkboxes = $(this).find("tbody input[type=checkbox]");
        let selectAll = $(this).find("#select-all");
        
        button.prop("disabled", checkboxes.filter(":checked").length === 0);
        if(checkboxes.length > 0) {
            selectAll.prop("checked", checkboxes.filter(":checked").length === checkboxes.length);
        }
    });

    $("#select-all").change(function() {
        let checkboxes = $("#delete-inventory-form").find("tbody input[type=checkbox]");
        checkboxes.prop('checked', $(this).is(":checked"));
    });

    // Edit Menu
    $("a.edit-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr("href"), 
            container: $("#edit-inventory-container"), 
            loader: $("#edit-inventory-loader")
        });
    });

    // Delete Menu/s
    $("#delete-inventory-form").submit(function(e) {
        e.preventDefault();

        method.destroy({
            modalHeader: "Delete Inventory Confirmation",
            modalText: "Once done, this action is irreversible. Are you sure you want to delete the selected inventory/ies?",
            form: $(this),
            container: $("#inventory-container"),
            button: [$("#delete-inventory-button"), $("#add-inventory-button")],
            selected: $("#delete-inventory-button"),
            text: ["Deleting Inventory/ies...", "Delete Inventory/ies"],
        });
    });
</script>