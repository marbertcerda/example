<form id="edit-table-form" action="{{set_route('tables.update', $table)}}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @method('put')
    @csrf

    <div class="flex flex-col sm:flex-row gap-2">
        <!-- Name -->
        <div class="w-full sm:w-2/3">
            <x-input-label for="new-name-field" value="Name: " />
            <x-text-input type="text" id="new-name-field" name="name" :value="old('name', $table->name)" placeholder="Enter table name" class="w-full" autofill autocomplete="name" />
            <x-input-error :messages="$errors->get('name')" data-error="name" />
        </div>

        <!-- seating capacity -->
        <div class="w-full sm:w-1/3">
            <x-input-label for="new-seating-capacity-field" value="Seating Capacity: " />
            <x-select name="seating_capacity" id="new-seating-capacity-field" class="w-full" autofill>
                <option value="" selected disabled>- Select One -</option>
                @foreach(App\Enums\SeatingCapacityEnum::cases() as $case)
                <option value="{{$case}}" @if($case === $table->seating_capacity) {{'selected'}} @endif>{{$case->name.' ('.$case->value.')'}}</option>
                @endforeach
            </x-select>
            <x-input-error :messages="$errors->get('size')" data-error="seating_capacity" />
        </div>
    </div>

    <!-- description -->
    <div class="prose">
        <x-input-label for="new-description-field" value="Description: " />
        <x-textarea id="new-description-field" name="description" class="w-full" placeholder="Enter table description" autofill>{!! old('description', $table->description) !!}</x-textarea>
        <x-input-error :messages="$errors->get('description')" data-error="description" />
    </div>

    <!-- photo -->
    <div>
        <x-input-label for="new-photo-field" value="Photo: " />
        <div id="new-photo-container" class="flex justify-center items-center h-56 w-full border-2 border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="new-upload-label" class="hidden label text-xs"> Tap Here to Upload Photo </div>
            <img id="new-photo-preview" src="{{asset('storage/tables/'.$table->photo)}}" alt="..." class="object-cover object-center">
        </div>
        <input type="file" name="photo" id="new-photo-field" accept="image/*" class="absolute opacity-0 pointer-events-none">
        <input type="hidden" id="old-photo-field" name="old-photo" value="{{asset('storage/tables/'.$table->photo)}}">
        <x-input-error :messages="$errors->get('photo')" data-error="photo" />
    </div>
</form>

<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="edit-table-form" id="edit-table-button"  class="form-button"> Update Table </x-primary-button>
</div>

<script type="module">
    // preload CKEditor
    let editor;
    $(document).ready(function() {
        let textField = $("#new-description-field").get(0);
        CkEditor.create(textField, {
            toolbar: [ "undo", "redo", "selectAll", "|", "heading", "|", "bold", "italic", "|", "link", "blockQuote", "|", "indent", "outdent", "bulletedList", "numberedList"]
        }).then(function(editField) {
            editor = editField;
        }).catch(function(error) {
            console.log(error);
        });
    });

    // photo preview
    $("#new-photo-container").click(function() {
        let fileInput = $("#new-photo-field");
        fileInput.click();
    });

    $("#new-photo-field").change(function(e) {
        let container = $("#new-photo-container");
        let preview = $("#new-photo-preview");
        let old = $("#old-photo-field");
        let label = $("#new-upload-label").val();
        let reader = new FileReader();


        if(this.files.length != 0) {
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
        }

        else {
            preview.attr('src', old);
        }
    });

    $("#edit-table-form").submit(function(e) {
        e.preventDefault();
        editor.updateSourceElement();

        method.submit({
            form: $(this),
            edit: true,
            editor: editor,
            indicator: $("#new-upload-label"),
            preview: $("#new-photo-preview"),
            container: $("#table-container"),
            selected: $("#edit-table-button"),
            button: $(".form-button"),
            text: ["Updating Table...", "Update Table"],
        });
    });
</script>