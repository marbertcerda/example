<x-app-layout>
    <x-slot name="header">
        <x-header>{{ __('Admin Tables Screen') }}</x-header>
    </x-slot>

    <x-section>
        <x-container>
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('tables.search')}}" method="get" class="w-full sm:w-1/3 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="delete-table-button" form="delete-table-form" :disabled="true">Delete Table/s</x-danger-button>
                        <x-primary-button id="add-table-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-add-table-form')">Add Table</x-primary-button>
                    </div>
                </div>
            </x-slot>
            <x-loader id="table-loader" />
            <div id="table-container" class="overflow-x-auto no-scrollbar">
                @include('admin.tables.tables')
            </div>
        </x-container>
    </x-section>

    <!-- Add table Form -->
    <x-modal name="show-add-table-form" title="Add New Table">
        @include('admin.tables.create')
    </x-modal>

    <!-- Edit table Form -->
    <x-modal name="show-edit-table-form" title="Edit Table" containerId="edit-table-container">
        <x-slot name="loader">
            <x-loader id="edit-table-loader" />
        </x-slot>
    </x-modal>

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#table-loader"),
                container: $("#table-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>