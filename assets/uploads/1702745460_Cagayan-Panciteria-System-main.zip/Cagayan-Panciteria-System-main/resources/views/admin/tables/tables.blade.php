<form id="delete-table-form" action="{{set_route('menu.destroy-multiple')}}" method="post">
    @method('delete')
    @csrf

    <x-table>
        <x-slot name="thead">
            <x-cell type="th">
                <x-checkbox id="select-all" />
            </x-cell>
            <x-cell type="th"></x-cell>
            <x-cell type="th">Name</x-cell>
            <x-cell type="th">Description</x-cell>
            <x-cell type="th">Seats</x-cell>
            <x-cell type="th">Date Added</x-cell>
            <x-cell type="th">Last Modified</x-cell>
        </x-slot>
        <x-slot name="tbody">
            @forelse($tables as $table)
            <tr>
                <x-cell type="td" align="center">
                    <x-checkbox name="table[]" :value="$table->id" />
                </x-cell>
                <x-cell type="td" class="w-12 h-12">
                    <img src="{{ asset('storage/tables/'.$table->photo) }}" alt="" class="w-full aspect-square rounded-full object-cover object-center">
                </x-cell>
                <x-cell type="td"><x-link href="{{set_route('tables.edit', $table)}}" x-data='' x-on:click.prevent="$dispatch('open-modal', 'show-edit-table-form')" class="edit-link">{{$table->name}}</x-link></x-cell>
                <x-cell type="td">{!! Illuminate\Support\Str::limit(strip_tags($table->description), 100, '...') !!}</x-cell>
                <x-cell type="td">{{$table->seating_capacity}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($table->created_at)->format('M d, Y \a\\t h:i A')}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($table->updated_at)->diffForHumans()}}</x-cell>
            </tr>
            @empty
            <tr>
                <x-cell type="td" colspan="7" align="center"> No Table found. Added Table/s will be shown here. </x-cell>
            </tr>
            @endforelse
        </x-slot>
    </x-table>
</form>

<script type="module">
    // Enable delete button if a checkbox is clicked
    $("#delete-table-form").change(function() {
        let button = $("#delete-table-button");
        let checkboxes = $(this).find("tbody input[type=checkbox]");
        let selectAll = $(this).find("#select-all");
        
        button.prop("disabled", checkboxes.filter(":checked").length === 0);
        if(checkboxes.length > 0) {
            selectAll.prop("checked", checkboxes.filter(":checked").length === checkboxes.length);
        }
    });

    $("#select-all").change(function() {
        let checkboxes = $("#delete-table-form").find("tbody input[type=checkbox]");
        checkboxes.prop('checked', $(this).is(":checked"));
    });

    // Edit Table
    $("a.edit-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr("href"), 
            container: $("#edit-table-container"), 
            loader: $("#edit-table-loader")
        });
    });

    // Delete Table/s
    $("#delete-table-form").submit(function(e) {
        e.preventDefault();

        method.destroy({
            modalHeader: "Delete Table Confirmation",
            modalText: "Once done, this action is irreversible. Are you sure you want to delete the selected table/s?",
            form: $(this),
            container: $("#table-container"),
            button: [$("#delete-table-button"), $("#add-table-button")],
            selected: $("#delete-table-button"),
            text: ["Deleting Table/s...", "Delete Table/s"],
        });
    });
</script>