<form id="delete-users-form" action="{{set_route('users.destroy-multiple')}}" method="post">
    @method('delete')
    @csrf

    <x-table>
        <x-slot name="thead">
            <x-cell type="th">
                <x-checkbox id="select-all" />
            </x-cell>
            <x-cell type="th"></x-cell>
            <x-cell type="th">Full name</x-cell>
            <x-cell type="th">Email</x-cell>
            <x-cell type="th">Phone Number</x-cell>
            <x-cell type="th">Role</x-cell>
            <x-cell type="th">Date Added</x-cell>
            <x-cell type="th">Last Modified</x-cell>
        </x-slot>
        <x-slot name="tbody">
            @forelse($users as $user)
            <tr>
                <x-cell type="td" align="center">
                    <x-checkbox name="user[]" :value="$user->id" />
                </x-cell>
                <x-cell type="td" class="w-12 h-12">
                    <img src="{{ asset('storage/profiles/'.$user->profile) }}" alt="" class="w-full aspect-square rounded-full object-cover object-center">
                </x-cell>
                
                <x-cell type="td"><x-link href="{{set_route('users.edit', $user)}}" x-data='' x-on:click.prevent="$dispatch('open-modal', 'show-edit-users-form')" class="edit-link">{{$user->last_name.", ".$user->first_name." ".$user->middle_name}}</x-link></x-cell>
                <x-cell type="td">{{$user->user->email}}</x-cell>
                <x-cell type="td">{{$user->phone_number}}</x-cell>
                <x-cell type="td">{{$user->is_admin? "admin" : "client"}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($user->created_at)->format('M d, Y \a\\t h:i A')}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($user->updated_at)->diffForHumans()}}</x-cell>
            </tr>
            @empty
            <tr>
                <x-cell type="td" colspan="8" align="center"> No Users found. Added User/s will be shown here.  </x-cell>
            </tr>
            @endforelse
        </x-slot>
    </x-table>
</form>

<script type="module">
    // Enable delete button if a checkbox is clicked
    $("#delete-users-form").change(function() {
        let button = $("#delete-users-button");
        let checkboxes = $(this).find("tbody input[type=checkbox]");
        let selectAll = $(this).find("#select-all");
        
        button.prop("disabled", checkboxes.filter(":checked").length === 0);
        if(checkboxes.length > 0) {
            selectAll.prop("checked", checkboxes.filter(":checked").length === checkboxes.length);
        }
    });

    $("#select-all").change(function() {
        let checkboxes = $("#delete-users-form").find("tbody input[type=checkbox]");
        checkboxes.prop('checked', $(this).is(":checked"));
    });

    // Edit Menu
    $("a.edit-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr("href"), 
            container: $("#edit-users-container"), 
            loader: $("#edit-users-loader")
        });
    });

    // Delete Menu/s
    $("#delete-users-form").submit(function(e) {
        e.preventDefault();

        method.destroy({
            modalHeader: "Delete User Confirmation",
            modalText: "Once done, this action is irreversible. Are you sure you want to delete the selected user/s?",
            form: $(this),
            container: $("#users-container"),
            button: [$("#delete-users-button"), $("#add-users-button")],
            selected: $("#delete-users-button"),
            text: ["Deleting User/s...", "Delete User/s"],
        });
    });
</script>