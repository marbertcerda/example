<form id="update-user-form" action="{{set_route('users.update', $user)}}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @method('put')
    @csrf

    <!-- Last Name -->
    <div>
        <x-input-label for="new-last-name-field" :value="__('Last Name')" />
        <x-text-input id="new-last-name-field" class="block w-full" type="text" name="last_name" :value="old('last_name', $user->last_name)" placeholder="Enter your last name" autofocus />
        <x-input-error :messages="$errors->get('last-name')" data-error="last_name" />
    </div>

    <!-- First Name -->
    <div>
        <x-input-label for="new-first-name-field" :value="__('First Name')" />
        <x-text-input id="new-first-name-field" class="block w-full" type="text" name="first_name" :value="old('first_name', $user->first_name)" placeholder="Enter your first name" autofocus />
        <x-input-error :messages="$errors->get('first-name')" data-error="first_name" />
    </div>

    <!-- Middle Name -->
    <div>
        <x-input-label for="new-middle-name-field" :value="__('Middle Name')" />
        <x-text-input id="new-middle-name-field" class="block w-full" type="text" name="middle_name" :value="old('middle_name', $user->middle_name)" placeholder="Enter your middle name" autofocus :required="false" />
        <x-input-error :messages="$errors->get('middle-name')" data-error="middle_name" />
    </div>

    <!-- Birthdate -->
    <div>
        <x-input-label for="new-birthdate-field" :value="__('Birthdate')" />
        <x-text-input id="new-birthdate-field" class="block w-full" type="date" name="birthdate" :value="old('birthdate', $user->birthdate)" autofocus />
        <x-input-error :messages="$errors->get('birthdate')" data-error="birthdate" />
    </div>

    <!-- Address -->
    <div>
        <x-input-label for="new-address-field" :value="__('Address')" />
        <x-text-input id="new-address-field" class="block w-full" type="text" name="address" :value="old('address', $user->address)" placeholder="Enter your current address" autofocus />
        <x-input-error :messages="$errors->get('address')" data-error="address" />
    </div>

    <!-- Phone Number -->
    <div>
        <x-input-label for="new-phone-number-field" :value="__('Phone Number')" />
        <x-text-input id="new-phone-number-field" class="block w-full" type="text" name="phone_number" :value="old('phone_number', $user->phone_number)" data-mask="0000-000-0000" placeholder="Ex: 09XX-XXX-XXXX" autofocus />
        <x-input-error :messages="$errors->get('phone-number')" data-error="phone_number" />
    </div>

    <!-- Profile -->
    <div>
        <x-input-label for="new-profile-field" :value="__('Profile')" />
        <div id="new-preview-container" class="flex justify-center items-center h-56 w-full border-2 border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="upload-label" class="hidden label text-xs"> Tap Here to Upload Photo </div>
            <img id="new-profile-preview" src="{{asset('storage/profiles/'.$user->profile)}}" alt="..." class="object-cover object-center">
        </div>
        <input type="file" name="profile" id="new-profile-field" accept="image/*" class="absolute opacity-0 pointer-events-none" required>
        <input type="hidden" id="old-profile-field" name="old_profile" value="{{asset('storage/profiles/'.$user->profile)}}">
        <x-input-error :messages="$errors->get('profile')" data-error="profile" />
    </div>

    <!-- Username -->
    <div>
        <x-input-label for="new-username-field" :value="__('Username')" />
        <x-text-input id="new-username-field" class="block w-full" type="text" name="username" :value="old('username', $user->user->username)" placeholder="Enter username" autofocus />
        <x-input-error :messages="$errors->get('username')" data-error="username" />
    </div>

    <!-- Email Address -->
    <div>
        <x-input-label for="new-email-field" :value="__('Email')" />
        <x-text-input id="new-email-field" class="block w-full" type="email" name="email" :value="old('email', $user->user->email)" placeholder="Enter email address" />
        <x-input-error :messages="$errors->get('email')" data-error="email" />
    </div>
</form>

<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="update-user-form" id="update-user-button"  class="form-button"> Update User </x-primary-button>
</div>

<script type="module">

    // profile preview
    $("#new-preview-container").click(function() {
        let fileInput = $("#new-profile-field");
        fileInput.click();
    });

    $("#new-profile-field").change(function(e) {
        let container = $("#new-preview-container");
        let preview = $("#new-profile-preview");
        let old = $("#old-profile-field").val();
        let reader = new FileReader();


        if(this.files.length != 0) {
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
            }
            reader.readAsDataURL(this.files[0]);
        }

        else {
            preview.attr('src', old);
        }
    });

    $("#update-user-form").submit(function(e) {
        e.preventDefault();

        method.submit({
            form: $(this),
            edit: true,
            indicator: $("#upload-label"),
            preview: $("#new-profile-preview"),
            container: $("#users-container"),
            selected: $("#update-user-button"),
            button: $(".form-button"),
            text: ["Updating User...", "Update User"],
        });
    });
</script>