<form id="add-user-form" action="{{ set_route('users.store') }}" method="post" enctype="multipart/form-data" class="px-0 sm:px-2 space-y-4">
    @csrf

    <!-- Last Name -->
    <div>
        <x-input-label for="last-name-field" :value="__('Last Name')" />
        <x-text-input id="last-name-field" class="block w-full" type="text" name="last_name" :value="old('last_name')" placeholder="Enter your last name" autofocus />
        <x-input-error :messages="$errors->get('last-name')" data-error="last_name" />
    </div>

    <!-- First Name -->
    <div>
        <x-input-label for="first-name-field" :value="__('First Name')" />
        <x-text-input id="first-name-field" class="block w-full" type="text" name="first_name" :value="old('first_name')" placeholder="Enter your first name" autofocus />
        <x-input-error :messages="$errors->get('first-name')" data-error="first_name" />
    </div>

    <!-- Middle Name -->
    <div>
        <x-input-label for="middle-name-field" :value="__('Middle Name')" />
        <x-text-input id="middle-name-field" class="block w-full" type="text" name="middle_name" :value="old('middle_name')" placeholder="Enter your middle name" autofocus :required="false" />
        <x-input-error :messages="$errors->get('middle-name')" data-error="middle_name" />
    </div>

    <!-- Birthdate -->
    <div>
        <x-input-label for="birthdate-field" :value="__('Birthdate')" />
        <x-text-input id="birthdate-field" class="block w-full" type="date" name="birthdate" :value="old('birthdate')" autofocus />
        <x-input-error :messages="$errors->get('birthdate')" data-error="birthdate" />
    </div>

    <!-- Address -->
    <div>
        <x-input-label for="address-field" :value="__('Address')" />
        <x-text-input id="address-field" class="block w-full" type="text" name="address" :value="old('address')" placeholder="Enter your current address" autofocus />
        <x-input-error :messages="$errors->get('address')" data-error="address" />
    </div>

    <!-- Phone Number -->
    <div>
        <x-input-label for="phone-number-field" :value="__('Phone Number')" />
        <x-text-input id="phone-number-field" class="block w-full" type="text" name="phone_number" :value="old('phone_number')" data-mask="0000-000-0000" placeholder="Ex: 09XX-XXX-XXXX" autofocus />
        <x-input-error :messages="$errors->get('phone-number')" data-error="phone_number" />
    </div>

    <!-- Profile -->
    <div>
        <x-input-label for="profile-field" :value="__('Profile')" />
        <div id="preview-container" class="flex justify-center items-center h-56 w-full border-2 border-dashed hover:border-solid border-gray-300 rounded-md overflow-hidden cursor-pointer transition-all duration-200">
            <div id="upload-label" class="label text-xs"> Tap Here to Upload Photo </div>
            <img id="profile-preview" src="" alt="..." class="hidden object-cover object-center">
        </div>
        <input type="file" name="profile" id="profile-field" accept="image/*" class="absolute opacity-0 pointer-events-none" required>
        <x-input-error :messages="$errors->get('profile')" data-error="profile" />
    </div>

    <!-- Username -->
    <div>
        <x-input-label for="username-field" :value="__('Username')" />
        <x-text-input id="username-field" class="block w-full" type="text" name="username" :value="old('username')" placeholder="Enter username" autofocus />
        <x-input-error :messages="$errors->get('username')" data-error="username" />
    </div>

    <!-- Email Address -->
    <div>
        <x-input-label for="email-field" :value="__('Email')" />
        <x-text-input id="email-field" class="block w-full" type="email" name="email" :value="old('email')" placeholder="Enter email address" />
        <x-input-error :messages="$errors->get('email')" data-error="email" />
    </div>

    <!-- Password -->
    <!-- <div>
        <x-input-label for="password-field" :value="__('Password')" />

        <x-text-input id="password-field" class="block w-full"
                        type="password"
                        name="password"
                        placeholder="Enter password" />

        <x-input-error :messages="$errors->get('password')" data-error="password" />
    </div> -->

    <!-- Confirm Password -->
    <!-- <div>
        <x-input-label for="password-confirmation-field" :value="__('Confirm Password')" />

        <x-text-input id="password-confirmation-field" class="block w-full"
                        type="password"
                        name="password_confirmation" placeholder="Confirm password" />

        <x-input-error :messages="$errors->get('password_confirmation')" data-error="password_confirmation" />
    </div> -->
</form>

<div class="flex justify-end gap-2 pt-6">
    <x-secondary-button x-on:click.prevent="$dispatch('close')" class="form-button">Close</x-secondary-button>
    <x-primary-button type="submit" form="add-user-form" id="add-user-button"  class="form-button"> Add New User </x-primary-button>
</div>

<script type="module">

    // profile preview
    $("#preview-container").click(function() {
        let fileInput = $("#profile-field");
        fileInput.click();
    });

    $("#profile-field").change(function(e) {
        let container = $("#preview-container");
        let preview = $("#profile-preview");
        let label = $("#upload-label");
        let reader = new FileReader();


        if(this.files.length != 0) {
            label.hide('fast', 'linear');
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
                preview.show('fast', 'linear');
            }
            reader.readAsDataURL(this.files[0]);
            container.removeClass("border-dashed");
        }

        else {
            preview.attr('src', '');
            preview.hide('fast', 'linear', function() {
                label.show('fast', 'linear');
                container.addClass("border-dashed");
            });
        }
    });

    $("#add-user-form").submit(function(e) {
        e.preventDefault();

        method.submit({
            form: $(this),
            edit: false,
            indicator: $("#upload-label"),
            preview: $("#profile-preview"),
            container: $("#users-container"),
            selected: $("#add-user-button"),
            button: $(".form-button"),
            text: ["Adding New User...", "Add New User"],
        });
    });
</script>