<x-app-layout>
    <x-slot name="header">
        <x-header>{{ __('Registered Users') }}</x-header>
    </x-slot>

    <x-section>
        <x-container>
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('users.search')}}" method="get" class="w-full sm:w-1/3 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="delete-users-button" form="delete-users-form" :disabled="true">Delete User/s</x-danger-button>
                        <x-primary-button id="add-users-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-add-users-form')">Add User</x-primary-button>
                    </div>
                </div>
            </x-slot>
            <x-loader id="users-loader" />
            <div id="users-container" class="overflow-x-auto no-scrollbar">
                @include('admin.users.users')
            </div>
        </x-container>
    </x-section>

    <!-- Add User Form -->
    <x-modal name="show-add-users-form" title="Add New User">
        @include('admin.users.create')
    </x-modal>

    <!-- Edit User Form -->
    <x-modal name="show-edit-users-form" title="Edit User" containerId="edit-users-container">
        <x-slot name="loader">
            <x-loader id="edit-users-loader" />
        </x-slot>
    </x-modal>

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#users-loader"),
                container: $("#users-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>