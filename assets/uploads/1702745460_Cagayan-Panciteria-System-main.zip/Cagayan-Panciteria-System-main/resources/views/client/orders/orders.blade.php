<form id="manage-order-form" method="post">
    @csrf

    <x-table>
        <x-slot name="thead">
            <x-cell type="th"><x-checkbox id="select-all" /></x-cell>
            <x-cell type="th">Menu Name</x-cell>
            <x-cell type="th">Quantity</x-cell>
            <x-cell type="th">Price</x-cell>
            <x-cell type="th">Notes</x-cell>
            <x-cell type="th">Status</x-cell>
            <x-cell type="th">Date Added</x-cell>
            <x-cell type="th">Last Modified</x-cell>
        </x-slot>
        <x-slot name="tbody">
            @forelse($orders as $order)
            <tr>
                <x-cell type="td">
                    <x-checkbox name="order[]" value="$order->id" />
                </x-cell>
                <x-cell type="td">
                    <x-link href="{{set_route('orders.edit', $order)}}" class="view-link" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-order-details-form')">
                        {{$order->menu->name}}
                    </x-link>
                </x-cell>
                <x-cell type="td">{{$order->quantity}}</x-cell>
                <x-cell type="td">@money($order->menu->size()->where("code", $order->size)->first()->pivot->price * $order->quantity)</x-cell>
                <x-cell type="td">{{Illuminate\Support\Str::limit($order->notes, 100, '...')}}</x-cell>
                <x-cell type="td">{{$order->status}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($order->created_at)->format('M d, Y \a\\t h:i A')}}</x-cell>
                <x-cell type="td">{{Carbon\Carbon::parse($order->updated_at)->diffForHumans()}}</x-cell>
            </tr>
            @empty
            <tr>
                <x-cell type="td" colspan="8" align="center"> No orders yet. Click <x-link></x-link> to add.</x-cell>
            </tr>
            @endforelse
        </x-slot>
    </x-table>
</form>

<script type="module">
    // Enable delete button if a checkbox is clicked
    $("#manage-order-form").change(function() {
        let button = $("#update-order-button");
        let checkboxes = $(this).find("tbody input[type=checkbox]");
        let selectAll = $(this).find("#select-all");
        
        button.prop("disabled", checkboxes.filter(":checked").length === 0);
        if(checkboxes.length > 0) {
            selectAll.prop("checked", checkboxes.filter(":checked").length === checkboxes.length);
        }
    });

    $("#select-all").change(function() {
        let checkboxes = $("#manage-order-form").find("tbody input[type=checkbox]");
        checkboxes.prop('checked', $(this).is(":checked"));
    });

    // Edit Menu
    $("a.view-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr("href"), 
            container: $("#order-details-container"), 
            loader: $("#order-details-loader")
        });
    });

    // Delete Menu/s
    $("#update-order-form").submit(function(e) {
        e.preventDefault();

        method.destroy({
            modalHeader: "Delete Menu Confirmation",
            modalText: "Once done, this action is irreversible. Are you sure you want to delete the selected orders?",
            form: $(this),
            container: $("#order-container"),
            button: [$("#update-order-button"), $("#add-order-button")],
            selected: $("#update-order-button"),
            text: ["Deleting Menu/s...", "Delete Menu/s"],
        });
    });
</script>