<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Client Order Screen') }}
        </h2>
    </x-slot>

    <x-section>
        <x-container>
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('orders.search')}}" method="get" class="w-full sm:w-1/2 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="cancel-order-button" form="cancel-order-form" :disabled="true">Delete Menu/s</x-danger-button>
                        <x-primary-button id="checkout-order-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-checkout-order-form')">Checkout?</x-primary-button>
                    </div>
                </div>
            </x-slot>
            <x-loader id="checkout-loader" />
            <div id="checkout-container" class="overflow-x-auto no-scrollbar">
                @include('client.orders.orders')
            </div>
        </x-container>

        <!-- View Associated Menu Details -->
        <x-modal name="show-order-details-form" title="Order Menu Details" containerId="order-details-container" maxWidth="5xl">
            <x-slot name="loader">
                <x-loader id="order-details-loader" />
            </x-slot>
        </x-modal>
    </x-section>

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#checkout-loader"),
                container: $("#checkout-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>