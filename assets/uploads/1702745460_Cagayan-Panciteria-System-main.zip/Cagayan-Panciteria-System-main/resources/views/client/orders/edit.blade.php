<div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
    <div class="basis-2/5">
        <img src="{{asset('storage/menus/'.$order->menu->photo)}}" alt="..." class="w-full aspect-square object-cover object-center">
    </div>
    <div class="grid sm:col-span-2 gap-4 sm:gap-8">
        <div>
            <p class="text-xl font-bold">{{$order->menu->name}}</p>
            <hr>
        </div>
        <div class="grid gap-4">
            <div class="prose">
                {!! $order->menu->description !!}
            </div>
            <div class="space-y-2">
                <p class="font-semibold text-lg">Available Sizes: </p>
                <table class="w-full">
                @foreach($order->menu->size as $serving)
                <tr>
                    <th align="left">{{ucwords($serving->description)}}</th>
                    <td>@money($serving->pivot->price)</td>
                </tr>
                @endforeach
                </table>
            </div>
        </div>
        <!-- Add Order Form -->
        <form id="update-order-form" action="{{set_route('orders.update', $order)}}" method="post">
            @method('put')
            @csrf

            <input type="hidden" name="menu" value="{{$order->menu->id}}">

            <div class="flex flex-col gap-2">
                <div class="flex flex-col sm:flex-row gap-2">
                    <!-- Size -->
                    <div class="w-full sm:w-2/3">
                        <x-input-label for="new-size-field" value="Size:" />
                        <x-text-input type="text" name="size" id="new-size-field" :value="old('size', ucwords($order->menu->size->where('code', $order->size)->first()->description))" class="w-full" readonly />
                        <x-input-error :messages="$errors->get('size')" data-error="size" />
                    </div>
                    <!-- Quantity -->
                    <div class="w-full sm:w-1/3">
                        <x-input-label for="new-quantity-field" value="Quantity:" />
                        <x-text-input type="number" id="new-quantity-field" name="quantity" :value="old('quantity', $order->quantity)" placeholder="Enter quantity" step="1" class="w-full" />
                        <x-input-error :messages="$errors->get('quantity')" data-error="quantity" />
                    </div>
                    <!-- Notes -->
                </div>
                <div class="w-full">
                    <x-input-label for="new-notes-field" value="Notes:" />
                    <x-textarea id="new-notes-field" name="notes" placeholder="Enter notes" rows="10" class="w-full">{{old('notes', $order->notes)}}</x-textarea>
                    <x-input-error :messages="$errors->get('notes')" data-error="notes" />
                </div>
            </div>
            <div class="pt-4">
                <x-primary-button id="update-order-button" type="submit">Update Order</x-primary-button>
            </div>
        </div>
    </div>
</div>

<div class="flex justify-end pt-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('close')">Close</x-primary-button>
</div>

<script type="module">
    $("#update-order-form").submit(function(e) {
        e.preventDefault();

        method.submit({
            form: $(this),
            edit: false,
            selected: $("#update-order-button"),
            button: $(this).find("button"),
            text: ["Adding Order...", "Add Order"],
        });
    });
</script>