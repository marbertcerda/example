<div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
    <div class="basis-2/5">
        <img src="{{asset('storage/tables/'.$table->photo)}}" alt="..." class="w-full aspect-square object-cover object-center">
    </div>
    <div class="grid sm:col-span-2 gap-4 sm:gap-8">
        <div>
            <p class="text-xl font-bold">{{$table->name}}</p>
            <hr>
        </div>
        <div class="grid gap-4">
            <div class="prose">
                {!! $table->description !!}
            </div>
            <div class="space-y-2">
                <p class="font-semibold text-lg">Available Schedules: </p>
                <div id="schedule-container"></div>
            </div>
        </div>
        <!-- Reserve Table Form -->
        <form id="add-reservation-form" action="{{set_route('reservations.store')}}" method="post">
            @csrf

            <input type="hidden" name="table" value="{{$table->id}}">

            <div class="flex flex-col gap-2">
                <!-- Date -->
                <div>
                    <x-input-label for="date-field" value="Date:" />
                    <x-text-input type="date" id="date-field" name="date" :value="old('date')" class="w-full"  />
                    <x-input-error :messages="$errors->get('date')" data-error="date" />
                </div>
                <div class="flex flex-col sm:flex-row gap-2">
                    <!-- Start -->
                    <div class="w-full sm:w-1/2">
                        <x-input-label for="start-field" value="Start:" />
                        <x-text-input type="time" id="start-field" name="start" :value="old('start')" class="w-full"  />
                        <x-input-error :messages="$errors->get('start')" data-error="start" />
                    </div>
                    <!-- end -->
                    <div class="w-full sm:w-1/2">
                        <x-input-label for="end-field" value="End:" />
                        <x-text-input type="time" id="end-field" name="end" :value="old('end')" class="w-full"  />
                        <x-input-error :messages="$errors->get('end')" data-error="end" />
                    </div>
                    <!-- Notes -->
                </div>
                <div class="w-full">
                    <x-input-label for="notes-field" value="Notes:" />
                    <x-textarea id="notes-field" name="notes" placeholder="Enter notes" rows="10" class="w-full"></x-textarea>
                    <x-input-error :messages="$errors->get('notes')" data-error="notes" />
                </div>
            </div>
            <x-primary-button id="add-reservation-button" type="submit" class="pt-4">Add Order</x-primary-button>
        </div>
    </div>
</div>

<div class="flex justify-end pt-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('close')">Close</x-primary-button>
</div>

<script type="module">
    // auto define end time
    $("#start-field").change(function() {
        let endField = $("#end-field");
        endField.val($(this).val());
        endField.get(0).stepUp(60);
    });

    $("#add-reservation-form").submit(function(e) {
        e.preventDefault();

        method.submit({
            form: $(this),
            edit: false,
            selected: $("#add-reservation-button"),
            button: $(this).find("button"),
            text: ["Adding Order...", "Add Order"],
        });
    });
</script>