@forelse($tables as $table)
<div class="flex flex-col justify-between bg-white sm:rounded-lg shadow-md overflow-hidden gap-4">
    <img src="{{asset('storage/tables/'.$table->photo)}}" class="aspect-video sm:aspect-square object-center object-cover" alt="...">
    <div class="p-3 space-y-4">
        <div>
            <x-link :href="set_route('tables.show', $table)" class="view-link text-lg font-semibold line-clamp-2" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-table-details-form')">{{$table->name}}</x-link>
            <p class="text-sm text-gray-600">
                {{ $table->seating_capacity->value." ".($table->seating_capacity->value > 1? "seats" : "seat")}}
            </p>
        </div>
        <x-primary-button value="{{set_route('tables.show', $table)}}" class="view-link w-full" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-table-details-form')">View Details</x-primary-button>
    </div>
</div>
@empty
<span class="col-span-1 sm:col-span-2 md:col-span-3 lg:col-span-4 text-center"> No Tables Available. </span>
@endforelse

<script type="module">
    $(".view-link").click(function(e) {
        e.preventDefault();

        method.load({
            link: $(this).attr($(this).is("button")? "value" : "href"), 
            container: $("#table-details-container"), 
            loader: $("#table-details-loader")
        });
    });
</script>