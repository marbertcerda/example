<x-app-layout>
    <x-slot name="header">
        <x-header>{{ __('Client Tables Screen') }}</x-header>
    </x-slot>

    <x-section>
        <x-container :hasBg="false">
            <x-slot name="header">
                <div class="flex flex-col sm:flex-row sm:justify-between gap-2">
                    <form id="search-form" action="{{set_route('tables.search')}}" method="get" class="w-full sm:w-2/3 md:w-2/5">
                        <x-text-input id="search-field" name="search" placeholder="Search here..." class="w-full" :required="false" />
                    </form>
                    <!-- <div class="flex justify-end sm:justify-normal gap-2">
                        <x-danger-button type="submit" id="delete-menu-button" form="delete-menu-form" :disabled="true">Delete Menu/s</x-danger-button>
                        <x-primary-button id="add-menu-button" x-data="" x-on:click.prevent="$dispatch('open-modal', 'show-add-menu-form')">Add Menu</x-primary-button>
                    </div> -->
                </div>
            </x-slot>
            <x-loader id="tables-loader" />
            <div id="tables-container" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                @include("client.tables.tables")
            </div>
        </x-container>
    </x-section>

    <!-- View Menu Details -->
    <x-modal name="show-table-details-form" title="Table Details" containerId="table-details-container" maxWidth="5xl">
        <x-slot name="loader">
            <x-loader id="table-details-loader" />
        </x-slot>
    </x-modal>

    <script type="module">
        // Search field
        $("#search-field").on('keyup', function(e) {
            if(e.which == 13) {
                $(this).triggerHandler("submit");
            }
        });

        $("#search-form").submit(function(e) {
            e.preventDefault();

            method.load({
                loader: $("#tables-loader"),
                container: $("#tables-container"),
                link: `${$(this).attr('action')}/${encodeURIComponent($("#search-field").val())}`
            });
        });
    </script>
</x-app-layout>