<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Client Home') }}
        </h2>
    </x-slot>

    <x-section>
        <x-container>
            <x-primary-button id="test-button"> Click to Test </x-primary-button>
        </x-container>

        <x-container>
            <p>this is another container within a section</p>
        </x-container>
    </x-section>
</x-app-layout>

<script type="module">
    $("#test-button").click(function(e) {
        e.preventDefault();

        Notify.push({
            title: "Test Notication",
            message: "If you're seeing this, then this notification is for test purposes only",
        });
    });
</script>