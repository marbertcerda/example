@props(["type" => ""])

@if($type == "th")
<th {{ $attributes->merge(["scope" => "col", "class" => "p-3 font-semibold tracking-wide text-left"]) }}>{{$slot}}</th>
@endif

@if($type == "td")
<td {{ $attributes->merge(["class" => "p-3"]) }}>{{$slot}}</td>
@endif