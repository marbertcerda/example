@props(["href" => ""])

<a href="{{$href}}" {{$attributes->merge(["class" => "underline font-semibold hover:text-gray-900 rounded-md  transition-all duration-200"])}}>{{$slot}}</a>