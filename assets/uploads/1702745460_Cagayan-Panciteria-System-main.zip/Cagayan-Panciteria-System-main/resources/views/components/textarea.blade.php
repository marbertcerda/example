@props(['disabled' => false, 'required' => false])

<textarea rows="6" {{$attributes->merge(['class' => 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm resize-none'])}}
    {{ $disabled ? 'disabled' : '' }}
    {{ $required ? 'required' : '' }}    
>{{$slot}}</textarea>