@props(['type' => 'loader'])

@php
    $class = $type === 'loader'
            ? "hidden absolute -translate-x-1/2 -translate-y-1/2 left-1/2 top-1/2"
            : "hidden";

    $size = $type === 'loader'
            ? "w-12 h-12"
            : "w-4 h-4";
    $fill = $type === 'loader'
            ? "fill-black"
            : "fill-white";   
@endphp

<div {{ $attributes->merge(["class" => "$class"])}}>
    <svg class="{{$size}} animate-spin {{$fill}}" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
        <g id="SVGRepo_iconCarrier"> 
            <path d="M12 22C17.5228 22 22 17.5228 22 12H19C19 15.866 15.866 19 12 19V22Z" fill="currentFill"></path> 
            <path d="M2 12C2 6.47715 6.47715 2 12 2V5C8.13401 5 5 8.13401 5 12H2Z" fill="currentFill"></path> 
        </g>
    </svg>
</div>