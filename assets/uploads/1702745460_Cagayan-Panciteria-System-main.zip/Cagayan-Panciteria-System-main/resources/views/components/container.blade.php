@props(["hasBg" =>true])

@php
    $border_radius = isset($header)? "sm:rounded-b-lg" : "sm:rounded-lg";
@endphp

<div {{ $attributes->merge(["class" => "max-w-7xl mx-auto sm:px-6 lg:px-8"]) }}>
    @if($hasBg)
        @if(isset($header))
        <div class="px-2 py-4 sm:px-6 sm:py-6 bg-gray-200 rounded-t-lg">
            {{$header}}
        </div>
        @endif
        <div class="px-2 py-4 sm:px-6 sm:py-6 bg-white shadow-sm {{$border_radius}}">
            <div class="relative min-h-[4rem] text-gray-900">
                {{ $slot }}
            </div>
        </div>

    @else
        @if(isset($header))
            <div class="px-4 py-4 sm:px-2 sm:py-6">
                {{$header}}
            </div>
        @endif
        <div class="px-4 sm:px-2 {{$border_radius}}">
            <div class="relative min-h-[4rem] text-gray-900">
                {{ $slot }}
            </div>
        </div>
    @endif
</div>