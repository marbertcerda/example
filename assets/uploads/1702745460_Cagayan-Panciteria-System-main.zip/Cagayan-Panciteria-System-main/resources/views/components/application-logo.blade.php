<div {{$attributes->merge(["class" => "aspect-square rounded-full overflow-hidden"])}}>
    <img src="{{ asset('images/logo.jpg') }}" alt="logo" class="w-full object-contain object-center">
</div>
