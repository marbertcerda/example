<table {{ $attributes->merge(["class" => "w-full"]) }}>
    @if(isset($thead))
    <thead>
        <tr>
            {{ $thead }}
        </tr>
    </thead>
    @endif

    @if(isset($tbody))
    <tbody>
        {{ $tbody }}
    </tbody>
    @endif
</table>