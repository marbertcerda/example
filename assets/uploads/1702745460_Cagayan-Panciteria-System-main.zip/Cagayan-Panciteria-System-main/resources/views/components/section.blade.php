<section {{ $attributes->merge(["class" => "py-4 first:pt-12 last:pb-6 space-y-4"]) }}>
    {{ $slot }}
</section>