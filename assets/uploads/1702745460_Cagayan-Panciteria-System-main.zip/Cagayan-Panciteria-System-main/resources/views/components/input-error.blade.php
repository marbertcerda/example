@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'text-sm text-red-600 space-y-1 mt-2']) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>

@else
    <div {{$attributes->merge(["class" => "hidden error text-sm text-red-600 space-y-1 mt-2 transition-all duration-200"])}}></div>
@endif
