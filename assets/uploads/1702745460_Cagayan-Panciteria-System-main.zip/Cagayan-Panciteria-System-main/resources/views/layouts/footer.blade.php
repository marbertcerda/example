
<footer class="bottom-0 bg-gray-100">
    <div class="w-full max-w-7xl mx-auto p-4 md:py-8">
        <div class="flex items-center gap-4">
            <a href="{{url('/')}}" class="flex items-center">
                <img src="{{asset('images/logo.jpg')}}" class="h-12 object-center object-cover rounded-full overflow-hidden" alt="..." />
                <span class="self-center text-2xl font-semibold whitespace-nowrap">INSERT COMPANY NAME</span>
            </a>
        </div>
        <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
        <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2023 <a href="{{url('/')}}" class="hover:underline">COMPANY NAME</a>. All Rights Reserved.</span>
    </div>
</footer>

