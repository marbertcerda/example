<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600">
        {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}
    </div>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <!-- Email Address -->
        <div>
            <x-input-label for="email-field" :value="__('Email')" />
            <x-text-input id="email-field" class="block mt-1 w-full" type="email" name="email" :value="old('email')" placeholder="Enter your email" autofocus />
            <x-input-error :messages="$errors->get('email')" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <x-primary-button id="send-reset-link-button" type="submit">
                {{ __('Send Reset Link') }}
            </x-primary-button>
        </div>
    </form>

    <script type="module">
        $('form').submit(function(e) {
            e.preventDefault();

            method.authenticate({
                form: $(this),
                redirect: false,
                selected: $("button#send-reset-link-button"),
                button: $(this).find("button"),
                text: ["Sending Reset Link...", "Send Reset Link"],
            });
        });
    </script>
</x-guest-layout>
