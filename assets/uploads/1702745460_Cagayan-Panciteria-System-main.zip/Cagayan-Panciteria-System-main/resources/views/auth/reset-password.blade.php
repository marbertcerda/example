<x-guest-layout>
    <form method="POST" action="{{ route('password.store') }}">
        @csrf

        <!-- Password Reset Token -->
        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <!-- Email Address -->
        <div>
            <x-input-label for="email-field" :value="__('Email')" />
            <x-text-input id="email-field" class="block mt-1 w-full" type="email" name="email" :value="old('email', $request->email)" placeholder="Enter your email" autofocus />
            <x-input-error :messages="$errors->get('email')" data-error="email" />
        </div>

        <!-- Password -->
        <div class="mt-4">
            <x-input-label for="password-field" :value="__('Password')" />
            <x-text-input id="password-field" class="block mt-1 w-full" type="password" name="password" placeholder="Enter new password" />
            <x-input-error :messages="$errors->get('password')" data-error="password" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-4">
            <x-input-label for="password_confirmation_field" :value="__('Confirm Password')" />

            <x-text-input id="password_confirmation_field" class="block mt-1 w-full"
                                type="password"
                                name="password_confirmation" 
                                placeholder="Confirm new password" />

            <x-input-error :messages="$errors->get('password_confirmation')" data-error="password_confirmation" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <x-primary-button id="reset-password-button" type="submit">
                {{ __('Reset Password') }}
            </x-primary-button>
        </div>
    </form>

    <script type="module">
        $('form').submit(function(e) {
            e.preventDefault();

            method.authenticate({
                form: $(this),
                redirect: true,
                button: $(this).find('button'),
                selected: $("#reset-password-button"),
                text: ["Resetting Password...", "Reset Password"],
            });
        });
    </script>
</x-guest-layout>
