<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Enums\InventoryUnitEnum;

class Inventory extends Model
{
    use HasFactory;

    protected $fillable = [
        "name",
        "description",
        "quantity",
        "stock",
        "unit",
        "photo",
    ];

    protected $hidden = [];

    protected $casts = [
        "unit" => InventoryUnitEnum::class,
    ];
}
