<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Menu;

class ServingSize extends Model
{
    use HasFactory;

    public function menu()
    {
        return $this->belongsToMany(Menu::class)->withPivot('price')->withTimeStamps();
    }

    protected $fillable = [
        "code",
        "description",
    ];

    protected $hidden = [];
    protected $casts = [];
}
