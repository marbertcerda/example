<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Menu;
use App\Models\User;
use App\Enums\OrderStatusEnum;
use App\Enums\ServingSizeEnum;

class Order extends Model
{
    use HasFactory;

    public function menu() {
        return $this->belongsTo(Menu::class);
    }

    public function user() {
        return $this->belongsToMany(User::class)->withTimeStamps();
    }

    protected $fillable = [
        "user_id",
        "menu_id",
        "size",
        "quantity",
        "notes",
        "status",
    ];

    protected $hidden = [
        "user_id",
    ];

    protected $casts = [
        "status" => OrderStatusEnum::class,
    ];
}
