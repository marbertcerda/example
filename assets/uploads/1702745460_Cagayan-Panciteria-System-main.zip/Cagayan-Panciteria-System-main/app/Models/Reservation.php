<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Casts\Time;
use App\Enums\ReservationStatusEnum;
use App\Models\User;
use App\Models\Table;

class Reservation extends Model
{
    use HasFactory;

    public function user() {
        return $this->belongsTo(User::class);
    }
    
    public function table() {
        return $this->belongsTo(Table::class);
    }

    protected $fillable = [
        "user_id",
        "table_id",
        "date",
        "start",
        "end",
        "notes",
        "status",
    ];

    protected $hidden = [
        "user_id",
        "table_id",
    ];

    protected $casts = [
        "start" => Time::class,
        "end" => Time::class,
    ];
}
