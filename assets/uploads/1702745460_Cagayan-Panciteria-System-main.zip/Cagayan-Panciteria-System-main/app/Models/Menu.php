<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

// use App\Enums\ServingSizeEnum;
use App\Models\ServingSize;
use App\Models\Order;

class Menu extends Model
{
    use HasFactory;

    public function order() {
        return $this->hasMany(Order::class);
    }

    public function size() {
        return $this->belongsToMany(ServingSize::class)->withPivot('price')->withTimeStamps();
    }

    protected $fillable = [
        "name",
        "description",
        // "size",
        // "price",
        "is_available",
        "photo",
    ];

    protected $hidden = [];

    protected $casts = [
        // "size" => ServingSizeEnum::class,
    ];
}
