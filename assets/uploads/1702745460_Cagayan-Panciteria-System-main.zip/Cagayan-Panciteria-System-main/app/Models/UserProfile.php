<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\User;

class UserProfile extends Model
{
    use HasFactory;

    public function user() {
        return $this->belongsTo(User::class);
    }
    
    protected $fillable = [
        "user_id",
        "first_name",
        "last_name",
        "middle_name",
        "birthdate",
        "address",
        "phone_number",
        "profile",
    ];

    protected $hidden = [];

    protected $casts = [
        // "birthdate" => "date_format:M d, Y"
    ];
}
