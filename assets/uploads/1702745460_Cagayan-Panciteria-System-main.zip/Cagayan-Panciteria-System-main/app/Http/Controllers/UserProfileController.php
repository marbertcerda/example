<?php

namespace App\Http\Controllers;

use App\Models\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
// use Illuminate\Support\Facades\Notification;

use Storage;
use App\Events\NotificationEvent;
use App\Models\User;
use App\Notifications\NewUser;

class UserProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $users = User::whereHas("profile")->latest("updated_at")->get();
        $users = UserProfile::with("user")->latest("updated_at")->get();
        return view("admin.users.index")->with(["users" => $users]);
    }

    public function users()
    {
        // $users = User::whereHas("profile")->latest("updated_at")->get();
        $users = UserProfile::with("user")->latest("updated_at")->get();
        return view("admin.users.users")->with(["users" => $users]);
    }

    public function search(Request $request) 
    {
        $users = UserProfile::where(function($query) use ($request) {
            $query->where("first_name", "like", $request->key."%")->orWhere("last_name", "like", $request->key."%")->orWhere("middle_name", "like", $request->key."%");
        })->latest("updated_at")->get();

        return view("admin.users.users")->with(["users" => $users]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_name' => ['nullable', 'max:255'],
            'birthdate' => ['required', 'date', 'before:today'],
            'address' => ['required', 'string', 'max:255'],
            'phone_number' => ['required', 'string', 'regex:/(^09+[0-9]{2})\-([0-9]{3})\-([0-9]{4})/'],
            'profile' => ['required', 'image', 'mimes:jpg,jpeg,png'],
            'username' => ['required', 'string', 'unique:users,username'],
            'email' => ['required', 'email', 'unique:users,email'],
        ]);

        // Save User Profile Photos to ther server
        $directory = "public/profiles";

        if(!Storage::exists($directory)) {
            Storage::makeDirectory($directory);
        }

        $image = $request->file('profile');
        $image_name = Str::random(40).".".$image->getClientOriginalExtension();
        $path = $image->storeAs($directory, $image_name);

        try {
            $pass = Str::random(10);
            $user = User::create([
                "username" => $request->username,
                "email" => $request->email,
                "password" => Hash::make($pass),
            ]);

            UserProfile::create([
                "user_id" => $user->id,
                "first_name" => $request->first_name,
                "last_name" => $request->last_name,
                "middle_name" => $request->middle_name ?? null,
                "birthdate" => $request->birthdate,
                "address" => $request->address,
                "phone_number" => $request->phone_number,
                "profile" => $image_name,
            ]);

            // $user->notify(new NewUser($user->username, $pass));

            return response()->json(["success" => true, "message" => "New user account created successfully.", "link" => set_route('users.list')]);
        } catch (\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to crete new user account. Please try again."]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(UserProfile $user)
    {
        // 
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UserProfile $user)
    {
        return view("admin.users.edit")->with(["user" => $user]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, UserProfile $user)
    {
        $validate = $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'middle_name' => ['nullable', 'max:255'],
            'birthdate' => ['required', 'date', 'before:today'],
            'address' => ['required', 'string', 'max:255'],
            'phone_number' => ['required', 'string', 'regex:/(^09+[0-9]{2})\-([0-9]{3})\-([0-9]{4})/'],
            'profile' => ['sometimes', 'required', 'image', 'mimes:jpg,jpeg,png'],
            'username' => ['required', 'string', Rule::unique('users', 'username')->ignore($user->user->id)],
            'email' => ['required', 'email', Rule::unique('users', 'email')->ignore($user->user->id)],
        ]);

        // Save User Profile Photos to ther server
        $directory = "public/profiles";

        if(isset($request->profile)) {
            if(Storage::exists("{$directory}/{$user->profile}")) {
                Storage::delete("{$directory}/{$user->profile}");
            }

            $image = $request->file('profile');
            $image_name = Str::random(40).".".$image->getClientOriginalExtension();
            $path = $image->storeAs($directory, $image_name);
        }

        try {
            
            $user->user->username = $request->username;
            $user->user->email = $request->email;
            $user->user->save();

            $user->first_name = $request->first_name;
            $user->middle_name = $request->middle_name;
            $user->last_name = $request->last_name;
            $user->birthdate = $request->birthdate;
            $user->address = $request->address;
            $user->phone_number = $request->phone_number;
            if(isset($request->profile)) {
                $user->profile = $image_name;
            }

            $user->save();

            return response()->json(["success" => true, "message" => "New user created successfully.", "link" => set_route('users.list')]);
        } catch (\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to update profile. Please try again."]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(UserProfile $user)
    {
        //
    }

    public function destroyMultiple(Request $request)
    {
        // $items = User::with("profile")->whereIn("id", $request->user)->get();
        $items = UserProfile::with("user")->whereIn("id", $request->user)->get();
        $directory = "public/profiles";

        try {
            foreach ($items as $data) {
                if(Storage::exists("{$directory}/{$data->profile}")) {
                    Storage::delete("{$directory}/{$data->profile}");
                }

                $data->delete();
                $data->user->delete();
            }

            return response()->json(["success" => true, "message" => "Selected user/s deleted successfully.", "link" => set_route("users.list")]);
        } catch (\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to deleted selected user/s. Please try again. "]);
        }

        
    }
}
