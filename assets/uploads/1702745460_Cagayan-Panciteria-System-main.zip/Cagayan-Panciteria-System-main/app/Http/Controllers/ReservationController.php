<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;
use Illumiate\Validation\Rules\Enum;

use App\Rules\ReservationTimeRule;
use App\Rules\ReservationStatusRule;
use App\Enums\ReservationStatusEnum;

class ReservationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $reservations = Reservation::latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $reservations = Reservation::where("user_id", Auth::id())->latest('updated_at')->get();
        }
        return view($prefix.".reservations.index")->with(["reservations" => $reservations]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            "date" => ["required", "date", "after:today", new ReservationTimeRule(), new ReservationStatusRule()],
            "start" => ["required", 'date_format:H:i', "after_or_equal:8:00", "before_or_equal:".Carbon::parse("20:00")->subHour()->format("H:i")],
            "end" => ["required", "date_format:H:i", "before_or_equal:20:00", "after_or_equal:".Carbon::parse("8:00")->addHour()->format("H:i")],
            "notes" => ["nullable", "string"],
        ]);

        $success = Reservation::create([
            "user_id" => Auth::id(),
            "table_id" => $request->table,
            "date" => $request->date,
            "start" => $request->start,
            "end" => $request->end,
            "notes" => $request->notes ?? null,
            "status" => ReservationStatusEnum::Pending,
        ]);

        if($success) {
            return response()->json(["success" => true, "message" => "Reservation successful"]);
        }

        return response()->json(["success" => false, "message" => "Failed to reserve selected table. Please try again."]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Reservation $reservation)
    {
        $prefix = Auth::user()->is_admin? "admin" : "client";
        return response()->json(["reservation" => $reservation]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Reservation $reservation)
    {
        return response()->json(["reservation" => $reservation]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Reservation $reservation)
    {
        $validate = $request->validate([
            "date" => ["required", "date", "after:today", new ReservationTimeRule(), new ReservationStatusRule()],
            "start" => ["required", 'date_format:H:i', "after_or_equal:8:00", "before:".Carbon::parse("20:00")->subHour()->format("H:i")],
            "end" => ["required", "date_format:H:i", "before_or_equal:20:00", "after_or_equal:".Carbon::parse("8:00")->addHour()->format("H:i")],
            "notes" => ["nullable", "string"],
        ]);

        $reservation->date = $request->date;
        $reservation->start = $request->start;
        $reservation->end = $request->end;
        $reservation->notes = $request->notes;
        $reservation->status = $request->status;
        $success = $reservation->save();

        if($success) {
            return response()->json(["success" => true, "message" => "Reservation details updated successfully."]);
        }
        return response()->json(["success" => true, "message" => "Failed to update reservation details. Please try again."]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Reservation $reservation)
    {
        $reservation->delete();
        return response()-> json(["success" => true, "message" => "Reservation successfully removed."]);
    }
}
