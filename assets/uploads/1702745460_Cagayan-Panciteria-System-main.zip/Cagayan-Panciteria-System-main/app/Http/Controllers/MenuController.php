<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Enum;

use Storage;
use App\Enums\ServingSizeEnum;
use App\Models\ServingSize;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $menus = Menu::latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $menus = Menu::where('is_available', true)->latest("updated_at")->get();
        }
        return view($prefix.".menu.index")->with(["menus" => $menus]);
    }

    public function menu()
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $menus = Menu::latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $menus = Menu::where('is_available', true)->latest("updated_at")->get();
        }
        return view($prefix.".menu.menus")->with(["menus" => $menus]);
    }

    public function search(Request $request)
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $menus = Menu::where(function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
            })->latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $menus = Menu::where(function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
                $query->where('is_available', true);
            })->latest("updated_at")->get();
        }
        return view($prefix.".menu.menus")->with(["menus" => $menus]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        if($request->user()->is_admin) {
            return view("admin.menu.create");
        }

        return abort(403);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if(!$request->user()->is_admin) {
            return response()->json(["success" => false, "message" => "You are not allowed to perform this action."]);
        }

        $validate = $request->validate([
            "name" => ["required", "string", "min:1"],
            "description" => ["required", "string", "min:1"],
            "size" => ["required"],
            "size.*" => ["sometimes", "required", new Enum(ServingSizeEnum::class)],
            "price.*" => ["required_if:size.*,accepted", "numeric", "min:1", "max:999.99"],
            "is_available" => ["nullable", "boolean"],
            "photo" => ["required", "image", "mimes:jpg,jpeg,png"],
        ]);

        $directory = "public/menus";
        if(!Storage::exists($directory)) {
            Storage::makeDirectory($directory);
        }

        // Upload to server
        $image = $request->file("photo");
        $image_name = Str::random(40).".".$image->getClientOriginalExtension();
        $path = $image->storeAs($directory, $image_name);

        try {
            $menu = Menu::create([
                "name" => $request->name,
                "description" => $request->description,
                "is_available" => $request->is_available ?? true,
                "photo" => $image_name,
            ]);
            $servings = ServingSize::whereIn("description", $request->size)->get();
            $toAttach = array();

            foreach($servings as $serving) {
                $toAttach[$serving->id] = ["price" => $request->price[$serving->code]];
            }

            $menu->size()->attach($toAttach);
            
            return response()->json(["success" => true, "message" => "Menu added successfully.", "link" => set_route('menu.list')]);
        } catch (\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to add new menu. Please try again.".$e]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request, Menu $menu)
    {
        $prefix = Auth::user()->is_admin ? "admin" : "client";
        return view($prefix.".menu.show")->with(["menu" => $menu]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, Menu $menu)
    {
        if(!$request->user()->is_admin) {
            return response()->json(["success" => false, "message" => "You are not allowed to perform this action."]);
        }
        $servings = array();
        foreach($menu->size as $val) {
            $servings[$val->code] = $val;
        }
        return view("admin.menu.edit")->with(["menu" => $menu, "servings" => $servings]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Menu $menu)
    {
        if(!$request->user()->is_admin) {
            return response()->json(["success" => false, "message" => "You are not allowed to perform this action."]);
        }

        $validate = $request->validate([
            "name" => ["required", "string", "min:1"],
            "description" => ["required", "string", "min:1"],
            "size" => ["required"],
            "size.*" => ["required", new Enum(ServingSizeEnum::class)],
            "price.*" => ["required", "numeric", "min:1", "max:999.99"],
            "is_available" => ["nullable", "boolean"],
            "photo" => ["sometimes", "required", "image", "mimes:jpg,jpeg,png"],
        ]);

        $directory = "public/menus";

        // delete old photo
        if(isset($request->photo)) {
            if(Storage::exists("{$directory}/{$menu->photo}")) {
                Storage::delete("{$directory}/{$menu->photo}");
            }

            // Upload new photo
            $image = $request->file("photo");
            $image_name = Str::random(40).".".$image->getClientOriginalExtension();
            $path = $image->storeAs($directory, $image_name);
        }

        // Update Fields
        $menu->name = $request->name;
        $menu->description = $request->description;
        // $menu->size = ServingSizeEnum::from($request->size);
        // $menu->price = $request->price;
        $menu->is_available = $request->is_available ?? false;
        if(isset($request->photo)) {
            $menu->photo = $image_name;
        }
        $success = $menu->save();

        $servings = ServingSize::whereIn("description", $request->size)->get();
        $update = array();

        // sync changes to pivot table
        foreach($servings as $serving) {
            $update[$serving->id] = ['price' => $request->price[$serving->code]];
        }
        $menu->size()->sync($update);

        // dd($servings);

        if($success) {
            return response()->json(["success" => true, "message" => "Menu Updated Successfully!", "link" => set_route('menu.list')]);
        }

        return response()->json(["success" => false, "message" => "Failed to update menu details. Please try again."]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Menu $menu)
    {
        if(!$request->user()->is_admin) {
            response()->json(["success" => false, "message" => "You are not allowed to perform this action."]);
        }

        // delete image from storage
        if(Storage::exists("public/menus/{$menu->photo}")) {
            Storage::delete("public/menus/{$menu->photo}");
        }

        $success = $menu->delete();

        if($success) {
            return response()->json(["success" => true, "message" => "Menu deleted successfully!"]);
        }

        return response()->json(["success" => false, "message" => "Failed to delete menu item. Please try again."]);
    }

    public function destroyMultiple(Request $request)
    {
        if(!$request->user()->is_admin) {
            return response()->json(["success" => false, "message" => "You are not allowed to perform this action."]);
        }

        if(!isset($request->menu)) {
            return response()->json(["success" => false, "message" => "Please select at least one menu to delete."]);
        }

        $items = Menu::whereIn('id', $request->menu)->get();

        try {
            foreach ($items as $data) {
                // delete image from storage
                if(Storage::exists("public/menus/{$data->photo}")) {
                    Storage::delete("public/menus/{$data->photo}");
                }

                // delete record
                $data->delete();
            }
            return response()->json(["success" => true, "message" => "Menu deleted successfully!", "link" => set_route('menu.list')]);
        }
        catch(\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to delete menu item. Please try again."]);
        }        
    }
}
