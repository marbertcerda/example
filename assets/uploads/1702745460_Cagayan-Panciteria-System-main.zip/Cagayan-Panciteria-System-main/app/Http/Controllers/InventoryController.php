<?php

namespace App\Http\Controllers;

use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Enum;

use Storage;
use App\Enums\InventoryUnitEnum;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $inventories = Inventory::latest('updated_at')->get();
        return view("admin.inventory.index")->with(['inventories' => $inventories]);
    }

    public function inventory()
    {
        $inventories = Inventory::latest('updated_at')->get();
        return view("admin.inventory.inventory")->with(['inventories' => $inventories]);
    }

    public function search(Request $request)
    {
        $inventories = inventory::where(function($query) use ($request) {
            $query->where("name", "like", "%".$request->key."%");
        })->latest("updated_at")->get();

        return view("admin.inventory.inventory")->with(['inventories' => $inventories]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            "name" => ["required", "string", "min:1"],
            "description" => ["nullable", "string"],
            "stock" => ["required", "numeric", "min:1", "max:999.99"],
            "unit" => ["required", new Enum(InventoryUnitEnum::class)],
            "photo" => ["required", "image", "mimes:jpg,jpeg,png"],
        ]);

        // Upload Image
        $directory = "public/inventories";
        if(!Storage::exists($directory)) {
            Storage::makeDirectory($directory);
        }

        $image = $request->file("photo");
        $image_name = Str::random(40).".".$image->getClientOriginalExtension();
        $path = $image->storeAs($directory, $image_name);

        $success = Inventory::create([
            "name" => $request->name,
            "description" => $request->description,
            "stock" => $request->stock,
            "unit" => InventoryUnitEnum::from($request->unit),
            "photo" => $image_name,
        ]);

        if($success) {
            return response()->json(["success" => $success, "message" => "New inventory added successfully.", "link" => set_route("inventory.list")]);
        }

        return response()->json(["success" => $success, "message" => "Failed to add new inventory. Please try again."]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Inventory $inventory)
    {
        return response()->json(["inventory" => $inventory]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Inventory $inventory)
    {
        return view("admin.inventory.edit")->with(["inventory" => $inventory]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Inventory $inventory)
    {
        $validate = $request->validate([
            "name" => ["required", "string", "min:2"],
            "description" => ["required", "string"],
            "stock" => ["required", "numeric", "min:1", "max:999.99"],
            "unit" => ["required", new Enum(InventoryUnitEnum::class)],
            "photo" => ["sometimes", "required", "image", "mimes:jpg,jpeg,png"],
        ]);

        $directory = "public/inventories";
        if(isset($request->photo)) {
            if(Storage::exists("{$directory}/{$inventory->photo}")) {
                Storage::delete("{$directory}/{$inventory->photo}");

                $image = $request->file("photo");
                $image_name = Str::random(40).".".$image->getClientOriginalExtension();
                $path = $image->storeAs($directory, $image_name);
            }
        }

        $inventory->name = $request->name;
        $inventory->description = $request->description;
        $inventory->stock = $request->stock;
        $inventory->unit = InventoryUnitEnum::from($request->unit);
        if(isset($request->photo)) {
            $inventory->photo = $image_name;
        }
        $success = $inventory->save();

        if($success) {
            return response()->json(["success" => $success, "message" => "Selected inventory updated successfully.", 
        "link" => set_route("inventory.list")]);
        }

        return response()->json(["success" => $success, "message" => "Failed to update inventory details. Please try again."]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Inventory $inventory)
    {
        $success = $inventory->delete();
        if($success) {
            return response()->json(["success" => $success, "message" => "Selected item was deleted successfully."]);
        }
        return response()->json(["success," => $success, "message" => "Failed to delete the selected item. Please try again."]);
    }

    public function destroyMultiple(Request $request)
    {
        $items = Inventory::whereIn('id', $request->inventory)->get();

        $directory = "public/inventories";
        try {
            foreach ($items as $data) {
                if(Storage::exists("{$directory}/{$data->photo}")) {
                    Storage::delete("{$directory}/{$data->photo}");
                }

                $data->delete();
            }

            return response()->json(["success" => true, "message" => "Selected items removed successfully.", "link" => set_route("inventory.list")]);
        } catch (\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to remove selected items. Please try again."]);
        }
    }
}
