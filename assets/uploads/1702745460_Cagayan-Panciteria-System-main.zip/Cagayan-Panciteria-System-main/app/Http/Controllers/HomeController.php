<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Events\NotificationEvent;

class HomeController extends Controller
{
    public function client()
    {
        event(new NotificationEvent(2, "Hi there, new user!", "order"));
        return view('client.index');
    }

    public function admin()
    {
        return view('admin.index');
    }

    public function guest()
    {
        return view('client.index');
    }
}
