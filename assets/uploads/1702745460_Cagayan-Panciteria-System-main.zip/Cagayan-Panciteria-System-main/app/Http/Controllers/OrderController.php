<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Enum;

use App\Enums\OrderStatusEnum;
use App\Enums\ServingSizeEnum;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $prefix = Auth::user()->is_admin ? "admin" : "client";
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $orders = Order::where('status', '!=', OrderStatusEnum::Completed)->get();
        }
        else {
            $prefix = "client";
            $orders = Order::where(function($query) {
                $query->where('user_id', Auth::id());
                $query->where("status", OrderStatusEnum::Add);
            })->latest("updated_at")->get();
        }
        return view($prefix.".orders.index")->with(["orders" => $orders]);
    }

    public function orders()
    {
        $prefix = Auth::user()->is_admin ? "admin" : "client";
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $orders = Order::with(["menu", "user"])->latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $orders = Order::where(function($query) {
                $query->where('user_id', Auth::id());
                $query->where("status", OrderStatusEnum::Add);
            })->latest("updated_at")->get();
        }
        return view($prefix.".orders.orders")->with(["orders" => $orders]);
    }

    public function search(Request $request)
    {
        $prefix = Auth::user()->is_admin ? "admin" : "client";
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $orders = Order::where(function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
                $query->where("status", '!=', OrderStatusEnum::Add)->orWhere("status", '!=', OrderStatusEnum::Completed)->orWhere("status", '!=', OrderStatusEnum::Cancelled);
            })->latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $orders = Order::where(function($query) use ($request) {
                $query->where('user_id', Auth::id());
                $query->where("status", OrderStatusEnum::Add);
            })->whereHas("menu", function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
            })->latest("updated_at")->get();
        }
        return view($prefix.".orders.orders")->with(["orders" => $orders]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            "size" => ["required", new Enum(ServingSizeEnum::class)],
            "quantity" => ["required", "integer", "min:1"],
            "notes" => ["sometimes", "required", "string", "min:1"],
        ]);

        $success = Order::updateOrCreate([
            "user_id" => Auth::id(),
            "menu_id" => $request->menu,
            "status" => OrderStatusEnum::Add,
            "size" => ServingSizeEnum::from($request->size)->name,
        ], [
            "quantity" => $request->quantity,
            "notes" => $request->notes ?? null,
            
        ]);

        if($success) {
            return response()->json(["success" => true, "message" => "Order added successfully."]);
        }

        return response()->json(["success" => false, "message" => "Failed to add order. Please try again."]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Order $order)
    {
        $prefix = Auth::user()->is_admin? "admin" : "client";
        return response()->json(["order" => $order]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Order $order)
    {
        if(Auth::user()->is_admin) {
            return abort(403);
        }
        return view("client.orders.edit")->with(["order" => $order]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Order $order)
    {
        $validate = $request->validate([
            "quantity" => ["required", "integer", "min:1"],
            "notes" => ["sometimes", "required", "string", "min:1"],
        ]);

        $order->quantity = $request->quantity;
        $order->notes = $request->notes;

        $success = $order->save();

        if($success) {
            return response()->json(["success" => true, "message" => "Order details updated successfully."]);
        }

        return response()->json(["success" => false, "message" => "Failed to update order details. Please try again."]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Order $order)
    {
        $order->delete();

        return response()->json(["success" => true, "message" => "Order deleted successfully."]);
    }

    public function destroyMultiple(Request $request)
    {
        if(!isset($request->order)) {
            return response()->json(["success" => false, "message" => "Please select at least one order to delete."]);
        }

        try {
            Order::whereIn("id", $request->order)->delete();
            return response()->json(["success" => true, "message" => "Selected Order/s removed successfully", "link" => set_route('orders.list')]);
        }

        catch(\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to remove selected order/s. Please try again."]);
        }
    }
}
