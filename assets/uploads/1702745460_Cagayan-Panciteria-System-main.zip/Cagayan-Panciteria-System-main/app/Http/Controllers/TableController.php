<?php

namespace App\Http\Controllers;

use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Enum;

use Storage;
use App\Enums\SeatingCapacityEnum;

class TableController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $tables = Table::latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $tables = Table::where("is_available", true)->latest("updated_at")->get();
        }

        return view($prefix.".tables.index")->with(["tables" => $tables]);
    }

    public function tables()
    {
        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $tables = Table::latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $tables = Table::where("is_available", true)->latest("updated_at")->get();
        }

        return view($prefix.".tables.tables")->with(["tables" => $tables]);
    }

    public function search(Request $request)
    {
        $prefix = Auth::user()->is_admin? 'admin' : 'client';
        $tables = Table::where(function($query) use ($request) {
            $query->where('name', 'like', '%'.$request->key.'%');
        })->latest("updated_at")->get();

        if(Auth::user()->is_admin) {
            $prefix = "admin";
            $tables = Table::where(function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
            })->latest("updated_at")->get();
        }
        else {
            $prefix = "client";
            $tables = Table::where(function($query) use ($request) {
                $query->where('name', 'like', '%'.$request->key.'%');
                $query->where("is_available", true);
            })->latest("updated_at")->get();
        }

        return view($prefix.".tables.tables")->with(["tables" => $tables]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validate = $request->validate([
            "name" => ["required", "string", "min:1"],
            "seating_capacity" => ["required", new Enum(SeatingCapacityEnum::class)],
            "description" => ["required", "string", "min:1"],
            "photo" => ["required", "image", "mimes:jpg,jpeg,png"],
        ]);

        $directory = "public/tables";

        // Store uploaded image
        if(!Storage::exists($directory)){
            Storage::makeDirectory($directory);
        }
        $image = $request->file("photo");
        $image_name = Str::random(40).".".$image->getClientOriginalExtension();
        $path = $image->storeAs($directory, $image_name);

        $success = Table::create([
            "name" => $request->name,
            "seating_capacity" => SeatingCapacityEnum::from($request->seating_capacity),
            "description" => $request->description,
            "photo" => $image_name,
        ]);

        if($success) {
            return response()->json(["success" => true, "message" => "New Table added successfully.", "link" => set_route('tables.list')]);
        }

        return response()->json(["success" => false, "message" => "Failed to add new table. Please try again."]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Table $table)
    {
        $prefix = Auth::user()->is_admin? "admin" : "client";
        return view($prefix.".tables.edit")->with(["table" => $table]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Table $table)
    {
        $prefix = Auth::user()->is_admin? "admin" : "client";
        return view($prefix.".tables.edit")->with(["table" => $table]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Table $table)
    {
        $validate = $request->validate([
            "name" => ["required", "string", "min:1"],
            "seating_capacity" => ["required", new Enum(SeatingCapacityEnum::class)],
            "description" => ["required", "string", "min:1"],
            "photo" => ["sometimes", "required", "image", "mimes:jpg,jpeg,png"],
        ]);

        $directory = "public/tables";

        // Delete old photo
        if(isset($request->photo)) {
            if(Storage::exists("{$directory}/{$table->photo}")) {
                Storage::delete("{$directory}/{$table->photo}");
            }
            // Upload new photo
            $image = $request->file("photo");
            $image_name = Str::random(40).".".$image->getClientOriginalExtension();
            $path = $image->storeAs($directory, $image_name);
        }

        // Update record
        $table->name = $request->name;
        $table->seating_capacity = SeatingCapacityEnum::from($request->seating_capacity);
        $table->description = $request->description;
        if(isset($request->photo)) {
            $table->photo = $image_name;
        }

        $success = $table->save();

        if($success) {
            return response()->json(["success" => true, "message" => "Table details updated successfully.", "link" => set_route('tables.list')]);
        }

        return response()->json(["success" => false, "message" => "Failed to update table details. Please try again"]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Table $table)
    {
        // delete image
        if(Storage::exists("public/tables/{$table->photo}")) {
            Storage::delete($table->photo);
        }
        $table->delete();

        return response()->json(["success" => true, "message" => "Table details successfully removed."]);
    }

    public function destroyMultiple(Request $request)
    {
        if(!isset($request->table)) {
            return response()->json(["success" => false, "message" => "Please select at least one item to delete."]);
        }

        $items = Table::whereIn('id', $request->table)->get();

        try {
            foreach ($items as $data) {
                // delete image from storage
                if(Storage::exists("public/tables/{$data->photo}")) {
                    Storage::delete("public/tables/{$data->photo}");
                }

                // delete record
                $data->delete();
            }
            return response()->json(["success" => true, "message" => "Table/s deleted successfully!", "link" => set_route('tables.list')]);
        }
        catch(\Exception $e) {
            return response()->json(["success" => false, "message" => "Failed to delete table item. Please try again."]);
        }
    }
}
