<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserProfile;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use Illuminate\Support\Str;
use Storage;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $request->validate([
            "first_name" => ['required', 'string', 'max:255'],
            "last_name" => ['required', 'string', 'max:255'],
            "middle_name" => ['nullable', 'max:255'],
            "birthdate" => ['required', 'date', "before:today"],
            "address" => ['required', 'string'],
            "phone_number" => ['required', 'regex:/(^09+[0-9]{2})\-([0-9]{3})\-([0-9]{4})/'],
            "profile" => ['required', 'image', 'mimes:jpg,jpeg,png'],
            'username' => ['required', 'string', 'max:255', 'unique:users,username'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:'.User::class],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        try {
            $user = User::create([
                'username' => $request->username,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
    
            // upload image
            $directory = "public/profiles";
            if(!Storage::exists($directory)) {
                Storage::makeDirectory($directory);
            }
    
            $image = $request->file("profile");
            $image_name = Str::random(40).".".$image->getClientOriginalExtension();
            $path = $image->storeAs($directory, $image_name);
    
            UserProfile::create([
                "user_id" => $user->id,
                "first_name" => $request->first_name,
                "last_name" => $request->last_name,
                "middle_name" => $request->middle_name ?? null,
                "birthdate" => $request->birthdate,
                "address" => $request->address,
                "phone_number" => $request->phone_number,
                "profile" => $image_name,
            ]);
    
            event(new Registered($user));
    
            // Auth::login($user);

            // $link = Auth::user()->is_admin? url(RouteServiceProvider::ADMIN) : url(RouteServiceProvider::CLIENT);
    
            return response()->json(['success' => true, 'message' => 'Registration success', "link" => url("/")]);
        }
        catch(\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Registration failed. Please try again.']);
        }
    }
}
