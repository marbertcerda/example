<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

if(!function_exists('set_route'))
{
    function set_route($model, $resource = null)
    {
        if(Auth::check()) {
            return route(Auth::user()->is_admin ? "admin.{$model}" : "client.{$model}", $resource);
        }

        return route("guest.{$model}", $resource);
    }
}

if(!function_exists('is_active'))
{
    function is_active($model, $resource = null)
    {
        if(Auth::check()) {
            return request()->routeIs(Auth::user()->is_admin ? "admin.{$model}" : "client.{$model}", $resource);
        }

        return request()->routeIs("guest.{$model}", $resource);
    }
}