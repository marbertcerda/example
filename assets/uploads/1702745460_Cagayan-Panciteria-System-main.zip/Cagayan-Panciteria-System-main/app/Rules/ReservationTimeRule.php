<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\Auth;
use App\Models\Reservation;

class ReservationTimeRule implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $request = (object) request()->only(['date', 'start', 'end']);
        $matches = Reservation::where(function($query) use($request) {
            $query->where('user_id', '!=', Auth::user()->id);
            $query->where('date', $request->date);
        })->where(function ($query) use ($request) {
            $query->where(function ($query) use ($request) {
                $query->where('start', '<', $request->start);
                $query->where('end', '>', $request->start);
            })->orWhere(function ($query) use ($request) {
                $query->where('start', '<', $request->end);
                $query->where('end', '>', $request->end);
            });
        })->count();

        if($matches > 0) {
            $fail('The :attribute must not conflict with existing bookings.');
        }
    }
}
