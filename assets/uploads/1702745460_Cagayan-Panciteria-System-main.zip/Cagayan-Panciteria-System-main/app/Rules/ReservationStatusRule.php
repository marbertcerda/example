<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Support\Facades\Auth;
use App\Models\Reservation;
use App\Enums\ReservationStatusEnum;

class ReservationStatusRule implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $request = (object) request()->only(["table"]);
        $doExists = Reservation::where(function($query) use ($request) {
            $query->where("user_id", Auth::id());
            $query->where("table_id", $request->table);
            $query->where("status", "!=", ReservationStatusEnum::Completed);
            $query->where("status", "!=", ReservationStatusEnum::Cancelled);
        })->exists();

        if($doExists) {
            $fail('The service should not be booked when ongoing request exists.');
        }
    }
}
