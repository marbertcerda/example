<?php

namespace App\Enums;

enum OrderStatusEnum:string {
    case Add = "for addition";
    case Pending = "pending";
    case Ready = "ready";
    case Cancelled = "cancelled";
    case Completed = "completed";
}