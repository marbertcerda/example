<?php
  
namespace App\Enums;
 
enum SeatingCapacityEnum:int {
    case Four = 4;
    case Five = 5;
    case Six = 6;
}