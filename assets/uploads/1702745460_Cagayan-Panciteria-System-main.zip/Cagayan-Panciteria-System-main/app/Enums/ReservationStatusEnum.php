<?php
  
namespace App\Enums;
 
enum ReservationStatusEnum:string {
    case Pending = "pending";
    case Accepted = "accepted";
    case Cancelled = "cancelled";
    case Completed = "completed";
}