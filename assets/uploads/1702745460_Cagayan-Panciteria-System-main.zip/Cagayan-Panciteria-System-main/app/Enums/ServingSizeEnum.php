<?php
  
namespace App\Enums;
 
enum ServingSizeEnum:string {
    case XS = 'extra small';
    case SM = 'small';
    case MD = 'medium';
    case LG = 'large';
    case XL = 'extra large';
    case XXL = 'double extra large';

    public static function fromName(string $name): string
    {
        foreach (self::cases() as $status) {
            if( $name === $status->name ){
                return $status;
            }
        }
        throw new \ValueError("$name is not a valid backing value for enum " . self::class );
    }
}