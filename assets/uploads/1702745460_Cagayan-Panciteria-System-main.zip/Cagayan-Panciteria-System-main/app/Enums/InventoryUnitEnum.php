<?php

namespace App\Enums;

enum InventoryUnitEnum: string {
    case kgs = "kilograms";
}