<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;


class NewUser extends Notification
{
    use Queueable;

    public $username;
    public $password;

    /**
     * Create a new notification instance.
     */
    public function __construct($username, $password)
    {
        $this->username = $username;
        $this->password = $password;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
                    ->greeting("Welcome Aboard, {$this->username}!")
                    ->line('Thank you for your on-site registration to our system. We are hoping for the best experience on our services.')
                    ->line('Please use this auto-generated password provided below to start using your account. You may click the button below to navigate directly to the login page.')
                    ->line("{$this->password}")
                    ->action('Log In', url('/login'))
                    ->line('Please remember to update password after logging in. Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
