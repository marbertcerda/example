<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        //
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        // Check for client priviledges
        Gate::define("client-only", function($user) {
            if(!$user->is_admin) {
                return true;
            }
            return false;
        });

        // check for admin priviledges
        // Check for client priviledges
        Gate::define("admin-only", function($user) {
            if($user->is_admin) {
                return true;
            }
            return false;
        });
    }
}
