<?php

use App\Http\Controllers\AuthenticateController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\VerifyUserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// routes for guest users
Route::middleware('guest')->group(function () {
    Route::get('/', [AuthenticateController::class, 'index'])->name('login');
    Route::post('/', [AuthenticateController::class, 'login'])->name('login.auth');
    Route::get('/register', [VerifyUserController::class, 'index'])->name('register');
    Route::post('/register', [VerifyUserController::class, 'register'])->name('register.auth');
});

// routes for authenticated users
Route::middleware('auth')->group(function () {
    Route::resource('employees', EmployeeController::class);
    Route::resource('departments', DepartmentController::class);
    Route::get('/logout', [AuthenticateController::class, 'logout'])->name('logout');
});
