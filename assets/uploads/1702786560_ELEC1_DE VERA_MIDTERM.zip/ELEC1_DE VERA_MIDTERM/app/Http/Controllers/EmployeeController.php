<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class EmployeeController extends Controller
{
    private $positions = [
        1 => 'Instructor I',
        2 => 'Instructor II',
        3 => 'Instructor III',
        4 => 'Associate Professor I',
        5 => 'Associate Professor II',
        6 => 'Associate Professor III',
    ];

    // method to display listings of employees
    public function index()
    {
        $employees = DB::table('employees')->get();
        return view('auth.employees', compact('employees'));
    }

    // method to show employee create form
    public function create()
    {
        $departments = DB::table('departments')->orderBy('dept_name')->get();
        return view(
            'auth.employees-form.add-employee',
            compact('departments'),
            ['positions' => $this->positions]
        );
    }

    // method to store employee record
    public function store(Request $request)
    {
        $this->validate($request, $this->validate_fields());
        DB::table('employees')->insert($this->insert_or_update_fields($request));
        return back()->with('success', 'Employee was created successfully!');
    }

    // method to find employee record and retrieve it in the form to update
    public function edit(string $id)
    {
        $employee = DB::table('employees')->where('emp_id', '=', $id)->first();
        $departments = DB::table('departments')->orderBy('dept_name')->get();
        $this->check_if_exists_model($employee);
        return view(
            'auth.employees-form.edit-employee',
            compact('employee', 'departments'),
            ['positions' => $this->positions],
        );
    }

    // method to update existing employee record
    public function update(Request $request, string $id)
    {
        $this->validate($request, $this->validate_fields($id));
        $employee = DB::table('employees')->where('emp_id', '=', $id);
        $this->check_if_exists_model($employee);
        $employee->update($this->insert_or_update_fields($request));
        return back()->with('success', 'Employee was updated successfully!');
    }

    // method to delete existing employee
    public function destroy(string $id)
    {
        $employee = DB::table('employees')->where('emp_id', '=', $id);
        $this->check_if_exists_model($employee);
        $employee->delete();
        return back()->with('success', 'Employee was deleted successfully!');
    }

    // method to check if the id or model is existing
    public function check_if_exists_model($employee): void
    {
        if (gettype($employee) == "NULL") {
            abort(404, 'No Employee Found!');
        }
    }

    // method to return associative array used in inserting or updating record
    public function insert_or_update_fields($request): array
    {
        return [
            'emp_name' => $request->name,
            'emp_address' => $request->address,
            'emp_department' => $request->department,
            'emp_email' => $request->email,
            'emp_contactNum' => $request->contact_number,
            'emp_dateEmployed' => date("Y-m-d", strtotime($request->date_employed)),
            'emp_position' => $request->position
        ];
    }

    // returns fields of validation
    public function validate_fields($id = null): array
    {
        return [
            'name' => 'required|max:50',
            'address' => 'required|max:50',
            'department' => 'required',
            'email' => ['required', 'email', Rule::unique('employees', 'emp_email')->ignore($id, 'emp_id')],
            'contact_number' => 'required|numeric|starts_with:09|digits:11',
            'date_employed' => 'required|date_format:m/d/Y',
            'position' => 'required'
        ];
    }
}
