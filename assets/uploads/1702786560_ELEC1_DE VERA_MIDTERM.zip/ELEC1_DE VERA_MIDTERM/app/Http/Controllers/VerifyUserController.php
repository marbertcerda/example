<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class VerifyUserController extends Controller
{
    public function index()
    {
        return view('register');
    }

    public function register(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|string|bail',
            'username' => 'required|unique:users,username|string|bail',
            'password' => 'required|min:6|max:32|string',
        ]);

        $validated_credentials = [
            'name' => $request->name,
            'username' => $request->username,
            'password' => Hash::make($request->password)
        ];

        DB::table('users')->insert($validated_credentials);

        return back()->with('success', 'User has been created!');
    }
}
