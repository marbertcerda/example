<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthenticateController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'username' => 'required|min:3|string|bail',
            'password' => 'required|min:6|string|bail'
        ]);

        if (auth()->attempt($request->only('username', 'password'))) {
            return redirect()->route('employees.index');
        } else {
            return back()->with('error', 'Username or Password is Incorrect!');
        }
    }

    public function logout()
    {
        auth()->logout();
        return redirect()->route('login');
    }
}
