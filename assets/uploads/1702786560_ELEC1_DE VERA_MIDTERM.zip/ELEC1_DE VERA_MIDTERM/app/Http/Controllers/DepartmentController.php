<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use function PHPSTORM_META\type;

class DepartmentController extends Controller
{
    // method to display listings of departments
    public function index()
    {
        $departments = DB::table('departments')->get();
        return view('auth.departments', compact('departments'));
    }

    // method to show department create form
    public function create()
    {
        return view('auth.departments-form.add-department');
    }

    // method to store department record
    public function store(Request $request)
    {
        $this->validate($request, $this->validate_fields());
        DB::table('departments')->insert($this->insert_or_update_fields($request));
        return back()->with('success', 'Department was created successfully!');
    }

    // method to find a department record and retrieve it in the form to update
    public function edit(string $id)
    {
        $department = DB::table('departments')->where('dept_id', '=', $id)->first();
        $this->check_if_exists_model($department);
        return view('auth.departments-form.edit-department', compact('department'));
    }

    // method to update existing department record
    public function update(Request $request, string $id)
    {
        $this->validate($request, $this->validate_fields());
        $department = DB::table('departments')->where('dept_id', '=', $id);
        $this->check_if_exists_model($department);
        $department->update($this->insert_or_update_fields($request));
        return back()->with('success', 'Department was updated successfully!');
    }

    // method to delete existing department record
    public function destroy(string $id)
    {
        $department = DB::table('departments')->where('dept_id', '=', $id);
        $this->check_if_exists_model($department);
        $department->delete();
        return back()->with('success', 'Department was deleted successfully!');
    }

    // method to check if the id or model is existing
    public function check_if_exists_model($department)
    {
        if (gettype($department) == "NULL") {
            abort(404, 'No Department Found!');
        }
    }

    // method to return associative array used in inserting or updating record
    public function insert_or_update_fields($request): array
    {
        return [
            'dept_name' => $request->department_name
        ];
    }

    // returns fields of validation
    public function validate_fields(): array
    {
        return [
            'department_name' => 'required|string|bail'
        ];
    }
}
