<!doctype html>
<html lang="en">

<head>
    <title>Dashboard</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php echo $__env->make('auth.scripts.cdn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
        body {
            background-image: url("psu_bg2.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <nav>
        <?php echo $__env->make('auth.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>

    <main>
        <div class="container py-5 px-3 mb-5">
            
            <h1 class="fw-bold mb-5">List of Employees
                <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success btn-md mx-3"><i
                        class="bi bi-plus-circle"></i></a>
            </h1>

            
            <?php if(Session::has('success')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>

            
            <table id="employees" class="table table-striped table-bordered table-responsive" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Department</th>
                        <th>Email</th>
                        <th>Contact #</th>
                        <th>Date Employed</th>
                        <th>Position</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($employee->emp_name); ?></td>
                            <td><?php echo e($employee->emp_address); ?></td>
                            <td><?php echo e($employee->emp_department); ?></td>
                            <td><?php echo e($employee->emp_email); ?></td>
                            <td><?php echo e($employee->emp_contactNum); ?></td>
                            <td><?php echo e($employee->emp_dateEmployed); ?></td>
                            <td><?php echo e($employee->emp_position); ?></td>
                            <td>
                                <div class="row">
                                    
                                    <div class="col-md-6 w-100">
                                        <form method="POST"
                                            action="<?php echo e(route('employees.destroy', $employee->emp_id)); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-md"
                                                title="Delete Employee"><i class="bi bi-trash3-fill"></i></button>
                                        </form>
                                    </div>

                                    
                                    <div class="col-md-6 w-100 mt-2">
                                        <a href="<?php echo e(route('employees.edit', $employee->emp_id)); ?>"
                                            class="btn btn-warning btn-md" title="Edit Employee"><i
                                                class="bi bi-pencil-fill"></i></a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <?php echo $__env->make('auth.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
        integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
    </script>
</body>

</html>

<script>
    $(document).ready(function() {
        $('#employees').DataTable();
    });
</script>
<?php /**PATH C:\Users\Jenny\MidtermExam\resources\views/auth/employees.blade.php ENDPATH**/ ?>