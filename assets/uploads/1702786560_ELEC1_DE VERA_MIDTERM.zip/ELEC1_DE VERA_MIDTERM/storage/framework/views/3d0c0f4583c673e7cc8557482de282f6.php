<footer class="text-center text-white bg-dark fixed-bottom">
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © <?php echo e(date('Y')); ?> Copyright:
        <a class="text-white" href="#">Midterm.com</a>
    </div>
    <!-- Copyright -->
</footer>
<?php /**PATH C:\Users\Jenny\MidtermExam\resources\views/auth/components/footer.blade.php ENDPATH**/ ?>