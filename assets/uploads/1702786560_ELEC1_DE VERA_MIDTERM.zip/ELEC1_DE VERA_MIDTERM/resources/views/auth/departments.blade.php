<!doctype html>
<html lang="en">

<head>
    <title>Departments</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    @include('auth.scripts.cdn')

    <style>
        body {
            background-image: url("psu_bg2.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <nav>
        @include('auth.components.navbar')
    </nav>

    <main>
        <div class="container py-5 px-3 mb-5">
            {{-- Link to Add an Department Record --}}
            <h1 class="fw-bold mb-5">List of Departments
                <a href="{{ route('departments.create') }}" class="btn btn-success btn-md mx-3"><i
                        class="bi bi-plus-circle"></i></a>
            </h1>

            {{-- If Actions is Success, Display Alert --}}
            @if (Session::has('success'))
                <div class="alert alert-danger" role="alert">
                    {{ Session::get('success') }}
                </div>
            @endif

            {{-- Listings of Departments --}}
            <table id="departments" class="table table-striped table-bordered table-responsive" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Department</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($departments as $department)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $department->dept_name }}</td>
                            <td>
                                <div class="row">
                                    {{-- Link to Delete an Department Record --}}
                                    <div class="col-md-2">
                                        <form method="post"
                                            action="{{ route('departments.destroy', $department->dept_id) }}">
                                            @method('DELETE')
                                            @csrf
                                            <button type="submit" class="btn btn-danger btn-md"
                                                title="Delete Department"><i class="bi bi-trash3-fill"></i>
                                            </button>
                                        </form>
                                    </div>

                                    {{-- Link to Edit an Department Record --}}
                                    <div class="col-md-2">
                                        <a href="{{ route('departments.edit', $department->dept_id) }}"
                                            class="btn btn-warning btn-md" title="Edit Department"><i
                                                class="bi bi-pencil-fill"></i></a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        @include('auth.components.footer')
    </footer>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
        integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
    </script>
</body>

</html>

<script>
    $(document).ready(function() {
        $('#departments').DataTable();
    });
</script>
