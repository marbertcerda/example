<!doctype html>
<html lang="en">

<head>
    <title>Edit Employee</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    @include('auth.scripts.cdn')

    <style>
        body {
            background-image: url("psu_bg2.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <nav>
        @include('auth.components.navbar')
    </nav>

    <main>
        <div class="container py-5">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <h1 class="fw-bold">Update a Employee</h1>
                    @if (Session::has('success'))
                        <div class="alert alert-warning" role="alert">
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    <form action="{{ route('employees.update', $employee->emp_id) }}" method="POST">
                        @method('PUT')
                        @csrf
                        <div class="row g-2">
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control @error('name') is-invalid @enderror"
                                        id="name" name="name" value="{{ $employee->emp_name }}">
                                    <label for="floatingInput">Employee Name</label>
                                    @error('name')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control @error('address') is-invalid @enderror"
                                        id="address" name="address" value="{{ $employee->emp_address }}">
                                    <label for="floatingInput">Employee Address</label>
                                    @error('address')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <select class="form-select @error('department') is-invalid @enderror"
                                        id="department" name="department" aria-label="Floating label select example">
                                        <option value="">Choose a Department</option>
                                        @foreach ($departments as $department)
                                            <option value="{{ $department->dept_name }}" @selected($employee->emp_department == $department->dept_name)>
                                                {{ $department->dept_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <label for="floatingSelectGrid">Department</label>
                                    @error('department')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <input type="email" class="form-control @error('email') is-invalid @enderror"
                                        id="email" name="email" value="{{ $employee->emp_email }}">
                                    <label for="floatingInput">Employee Email</label>
                                    @error('email')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <input type="text"
                                        class="form-control @error('contact_number') is-invalid @enderror"
                                        id="contact_number" name="contact_number" value="{{ $employee->emp_contactNum }}">
                                    <label for="floatingInput">Employee Contact #</label>
                                    @error('contact_number')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <input type="text"
                                        class="form-control @error('date_employed') is-invalid @enderror"
                                        id="date_employed" name="date_employed" value="{{ date('m/d/Y', strtotime($employee->emp_dateEmployed)) }}">
                                    <label for="floatingInput">Employee Date Employed</label>
                                    @error('date_employed')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <div class="form-floating mb-3">
                                    <select class="form-select @error('position') is-invalid @enderror" id="position"
                                        name="position" aria-label="Floating label select example">
                                        <option value="">Choose a Position</option>
                                        @foreach ($positions as $key => $position)
                                            <option value="{{ $position }}" @selected($employee->emp_position == $position)>
                                                {{ $position }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <label for="floatingSelectGrid">Position</label>
                                    @error('position')
                                        <span class="invalid-feedback">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                        <a href="{{ route('employees.index') }}" class="btn btn-secondary">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer>
        @include('auth.components.footer')
    </footer>
</body>

</html>

<script>
    $(function() {
        $('#date_employed').datepicker();
    });
</script>
