<!doctype html>
<html lang="en">

<head>
    <title>Edit Department</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    @include('auth.scripts.cdn')

    <style>
        body {
            background-image: url("psu_bg2.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <nav>
        @include('auth.components.navbar')
    </nav>

    <main>
        <div class="container py-5">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <h1 class="fw-bold">Edit a Department</h1>
                    @if (Session::has('success'))
                        <div class="alert alert-warning" role="alert">
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    <form action="{{ route('departments.update', $department->dept_id) }}" method="POST">
                        @method('PUT')
                        @csrf
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control @error('department_name') is-invalid @enderror"
                                id="department_name" name="department_name" value="{{ $department->dept_name }}">
                            <label for="floatingInput">Department Name</label>
                            @error('department_name')
                                <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                        <a href="{{ route('departments.index') }}" class="btn btn-secondary">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer>
        @include('auth.components.footer')
    </footer>
</body>

</html>
